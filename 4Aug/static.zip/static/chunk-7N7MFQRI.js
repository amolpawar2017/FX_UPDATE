import"./chunk-BCCDUILC.js";import{b as qt}from"./chunk-PX3UZRRK.js";import{a as xt}from"./chunk-HDFBS7AW.js";import{b as At,c as Et,d as Tt,e as Dt,f as Ft,g as zt,h as Rt,i as Pt,j as Nt,k as Bt}from"./chunk-JAO5EW2C.js";import{a as Gt}from"./chunk-3D3FRWOZ.js";import{a as Wt}from"./chunk-U4YX2DQY.js";import{d as Vt,f as Ht,k as Qt,m as Ut,n as $t}from"./chunk-PNTILEUX.js";import{b as rt,d as Q,f as st,g as mt,j as dt,l as pt,m as ht,p as _t,q as gt,r as bt}from"./chunk-5AU5NM3W.js";import{a as Ct}from"./chunk-BHI5CEHR.js";import"./chunk-X6W5R2HS.js";import{a as ut,f as ft,i as vt,k as kt,la as Mt,m as wt,ma as St,p as L,pa as It,qa as Lt,sa as Ot,y as yt}from"./chunk-VJULX6IE.js";import{a as jt}from"./chunk-254FYNHO.js";import{d as nt,e as at,f as ot,u as ct,v as lt}from"./chunk-FYW6F2XK.js";import{$a as r,$b as V,Da as O,Db as R,Fa as F,H as Z,K as D,Kb as m,Lb as a,Mb as o,Nb as f,Rb as x,Sb as v,Ub as P,Yb as b,_b as p,a as W,ac as k,b as X,bc as H,ca as Y,cc as et,dc as w,ec as y,fa as N,ga as B,h as K,ha as g,ib as z,kc as C,ma as M,mc as c,na as S,nc as _,ob as A,oc as I,qa as J,qb as u,s as T,tb as E,ub as d,va as tt,vc as it,ya as j}from"./chunk-OYT7HEGD.js";var Kt=[{value:"NONE",label:"Not on chart"},{value:"MID",label:"Mid Price"},{value:"OPEN",label:"Open Price"},{value:"HIGH",label:"High Price"},{value:"LOW",label:"Low Price"},{value:"CLOSE",label:"Close Price"},{value:"VOLUME",label:"Volume"}],Zt=(()=>{class e{http;config;constructor(t,i){this.http=t,this.config=i}get base(){return`${this.config.getApiUrl()}/attribute-mappings`}getAll(t){let i=new ct;return t&&(i=i.set("topic",t)),this.http.get(this.base,{params:i})}create(t){return this.http.post(this.base,t)}update(t,i){return this.http.put(`${this.base}/${t}`,i)}delete(t){return this.http.delete(`${this.base}/${t}`)}static \u0275fac=function(i){return new(i||e)(B(lt),B(jt))};static \u0275prov=Y({token:e,factory:e.\u0275fac,providedIn:"root"})}return e})();var ne=["*"],ae=`.mdc-list {
  margin: 0;
  padding: 8px 0;
  list-style-type: none;
}
.mdc-list:focus {
  outline: none;
}

.mdc-list-item {
  display: flex;
  position: relative;
  justify-content: flex-start;
  overflow: hidden;
  padding: 0;
  align-items: stretch;
  cursor: pointer;
  padding-left: 16px;
  padding-right: 16px;
  background-color: var(--mat-list-list-item-container-color, transparent);
  border-radius: var(--mat-list-list-item-container-shape, var(--mat-sys-corner-none));
}
.mdc-list-item.mdc-list-item--selected {
  background-color: var(--mat-list-list-item-selected-container-color);
}
.mdc-list-item:focus {
  outline: 0;
}
.mdc-list-item.mdc-list-item--disabled {
  cursor: auto;
}
.mdc-list-item.mdc-list-item--with-one-line {
  height: var(--mat-list-list-item-one-line-container-height, 48px);
}
.mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__start {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__end {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-two-lines {
  height: var(--mat-list-list-item-two-line-container-height, 64px);
}
.mdc-list-item.mdc-list-item--with-two-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--with-two-lines .mdc-list-item__end {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-three-lines {
  height: var(--mat-list-list-item-three-line-container-height, 88px);
}
.mdc-list-item.mdc-list-item--with-three-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--with-three-lines .mdc-list-item__end {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--selected::before, .mdc-list-item.mdc-list-item--selected:focus::before, .mdc-list-item:not(.mdc-list-item--selected):focus::before {
  position: absolute;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  content: "";
  pointer-events: none;
}

a.mdc-list-item {
  color: inherit;
  text-decoration: none;
}

.mdc-list-item__start {
  fill: currentColor;
  flex-shrink: 0;
  pointer-events: none;
}
.mdc-list-item--with-leading-icon .mdc-list-item__start {
  color: var(--mat-list-list-item-leading-icon-color, var(--mat-sys-on-surface-variant));
  width: var(--mat-list-list-item-leading-icon-size, 24px);
  height: var(--mat-list-list-item-leading-icon-size, 24px);
  margin-left: 16px;
  margin-right: 32px;
}
[dir=rtl] .mdc-list-item--with-leading-icon .mdc-list-item__start {
  margin-left: 32px;
  margin-right: 16px;
}
.mdc-list-item--with-leading-icon:hover .mdc-list-item__start {
  color: var(--mat-list-list-item-hover-leading-icon-color);
}
.mdc-list-item--with-leading-avatar .mdc-list-item__start {
  width: var(--mat-list-list-item-leading-avatar-size, 40px);
  height: var(--mat-list-list-item-leading-avatar-size, 40px);
  margin-left: 16px;
  margin-right: 16px;
  border-radius: 50%;
}
.mdc-list-item--with-leading-avatar .mdc-list-item__start, [dir=rtl] .mdc-list-item--with-leading-avatar .mdc-list-item__start {
  margin-left: 16px;
  margin-right: 16px;
  border-radius: 50%;
}

.mdc-list-item__end {
  flex-shrink: 0;
  pointer-events: none;
}
.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  font-family: var(--mat-list-list-item-trailing-supporting-text-font, var(--mat-sys-label-small-font));
  line-height: var(--mat-list-list-item-trailing-supporting-text-line-height, var(--mat-sys-label-small-line-height));
  font-size: var(--mat-list-list-item-trailing-supporting-text-size, var(--mat-sys-label-small-size));
  font-weight: var(--mat-list-list-item-trailing-supporting-text-weight, var(--mat-sys-label-small-weight));
  letter-spacing: var(--mat-list-list-item-trailing-supporting-text-tracking, var(--mat-sys-label-small-tracking));
}
.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-trailing-icon-color, var(--mat-sys-on-surface-variant));
  width: var(--mat-list-list-item-trailing-icon-size, 24px);
  height: var(--mat-list-list-item-trailing-icon-size, 24px);
}
.mdc-list-item--with-trailing-icon:hover .mdc-list-item__end {
  color: var(--mat-list-list-item-hover-trailing-icon-color);
}
.mdc-list-item.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  color: var(--mat-list-list-item-trailing-supporting-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-list-item--selected.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-selected-trailing-icon-color, var(--mat-sys-primary));
}

.mdc-list-item__content {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  align-self: center;
  flex: 1;
  pointer-events: none;
}
.mdc-list-item--with-two-lines .mdc-list-item__content, .mdc-list-item--with-three-lines .mdc-list-item__content {
  align-self: stretch;
}

.mdc-list-item__primary-text {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  color: var(--mat-list-list-item-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-list-list-item-label-text-font, var(--mat-sys-body-large-font));
  line-height: var(--mat-list-list-item-label-text-line-height, var(--mat-sys-body-large-line-height));
  font-size: var(--mat-list-list-item-label-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-list-list-item-label-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-list-list-item-label-text-tracking, var(--mat-sys-body-large-tracking));
}
.mdc-list-item:hover .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-hover-label-text-color, var(--mat-sys-on-surface));
}
.mdc-list-item:focus .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-focus-label-text-color, var(--mat-sys-on-surface));
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text, .mdc-list-item--with-three-lines .mdc-list-item__primary-text {
  display: block;
  margin-top: 0;
  line-height: normal;
  margin-bottom: -20px;
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before, .mdc-list-item--with-three-lines .mdc-list-item__primary-text::before {
  display: inline-block;
  width: 0;
  height: 28px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after, .mdc-list-item--with-three-lines .mdc-list-item__primary-text::after {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: -20px;
}

.mdc-list-item__secondary-text {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  display: block;
  margin-top: 0;
  color: var(--mat-list-list-item-supporting-text-color, var(--mat-sys-on-surface-variant));
  font-family: var(--mat-list-list-item-supporting-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-list-list-item-supporting-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-list-list-item-supporting-text-size, var(--mat-sys-body-medium-size));
  font-weight: var(--mat-list-list-item-supporting-text-weight, var(--mat-sys-body-medium-weight));
  letter-spacing: var(--mat-list-list-item-supporting-text-tracking, var(--mat-sys-body-medium-tracking));
}
.mdc-list-item__secondary-text::before {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-three-lines .mdc-list-item__secondary-text {
  white-space: normal;
  line-height: 20px;
}
.mdc-list-item--with-overline .mdc-list-item__secondary-text {
  white-space: nowrap;
  line-height: auto;
}

.mdc-list-item--with-leading-radio.mdc-list-item,
.mdc-list-item--with-leading-checkbox.mdc-list-item,
.mdc-list-item--with-leading-icon.mdc-list-item,
.mdc-list-item--with-leading-avatar.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
[dir=rtl] .mdc-list-item--with-leading-radio.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-checkbox.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-icon.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-avatar.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text {
  display: block;
  margin-top: 0;
  line-height: normal;
  margin-bottom: -20px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before {
  display: inline-block;
  width: 0;
  height: 32px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: -20px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  display: block;
  margin-top: 0;
  line-height: normal;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before {
  display: inline-block;
  width: 0;
  height: 32px;
  content: "";
  vertical-align: 0;
}

.mdc-list-item--with-trailing-icon.mdc-list-item, [dir=rtl] .mdc-list-item--with-trailing-icon.mdc-list-item {
  padding-left: 0;
  padding-right: 0;
}
.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  margin-left: 16px;
  margin-right: 16px;
}

.mdc-list-item--with-trailing-meta.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-meta.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  -webkit-user-select: none;
  user-select: none;
  margin-left: 28px;
  margin-right: 16px;
}
[dir=rtl] .mdc-list-item--with-trailing-meta .mdc-list-item__end {
  margin-left: 16px;
  margin-right: 28px;
}
.mdc-list-item--with-trailing-meta.mdc-list-item--with-three-lines .mdc-list-item__end, .mdc-list-item--with-trailing-meta.mdc-list-item--with-two-lines .mdc-list-item__end {
  display: block;
  line-height: normal;
  align-self: flex-start;
  margin-top: 0;
}
.mdc-list-item--with-trailing-meta.mdc-list-item--with-three-lines .mdc-list-item__end::before, .mdc-list-item--with-trailing-meta.mdc-list-item--with-two-lines .mdc-list-item__end::before {
  display: inline-block;
  width: 0;
  height: 28px;
  content: "";
  vertical-align: 0;
}

.mdc-list-item--with-leading-radio .mdc-list-item__start,
.mdc-list-item--with-leading-checkbox .mdc-list-item__start {
  margin-left: 8px;
  margin-right: 24px;
}
[dir=rtl] .mdc-list-item--with-leading-radio .mdc-list-item__start,
[dir=rtl] .mdc-list-item--with-leading-checkbox .mdc-list-item__start {
  margin-left: 24px;
  margin-right: 8px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__start,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 8px;
}

.mdc-list-item--with-trailing-radio.mdc-list-item,
.mdc-list-item--with-trailing-checkbox.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
.mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-icon, .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-avatar,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-icon,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-avatar {
  padding-left: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-icon, [dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-avatar,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-icon,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-avatar {
  padding-right: 0;
}
.mdc-list-item--with-trailing-radio .mdc-list-item__end,
.mdc-list-item--with-trailing-checkbox .mdc-list-item__end {
  margin-left: 24px;
  margin-right: 8px;
}
[dir=rtl] .mdc-list-item--with-trailing-radio .mdc-list-item__end,
[dir=rtl] .mdc-list-item--with-trailing-checkbox .mdc-list-item__end {
  margin-left: 8px;
  margin-right: 24px;
}
.mdc-list-item--with-trailing-radio.mdc-list-item--with-three-lines .mdc-list-item__end,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-three-lines .mdc-list-item__end {
  align-self: flex-start;
  margin-top: 8px;
}

.mdc-list-group__subheader {
  margin: 0.75rem 16px;
}

.mdc-list-item--disabled .mdc-list-item__start,
.mdc-list-item--disabled .mdc-list-item__content,
.mdc-list-item--disabled .mdc-list-item__end {
  opacity: 1;
}
.mdc-list-item--disabled .mdc-list-item__primary-text,
.mdc-list-item--disabled .mdc-list-item__secondary-text {
  opacity: var(--mat-list-list-item-disabled-label-text-opacity, 0.3);
}
.mdc-list-item--disabled.mdc-list-item--with-leading-icon .mdc-list-item__start {
  color: var(--mat-list-list-item-disabled-leading-icon-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-leading-icon-opacity, 0.38);
}
.mdc-list-item--disabled.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-disabled-trailing-icon-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-trailing-icon-opacity, 0.38);
}

.mat-mdc-list-item.mat-mdc-list-item-both-leading-and-trailing, [dir=rtl] .mat-mdc-list-item.mat-mdc-list-item-both-leading-and-trailing {
  padding-left: 0;
  padding-right: 0;
}

.mdc-list-item.mdc-list-item--disabled .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-disabled-label-text-color, var(--mat-sys-on-surface));
}

.mdc-list-item:hover::before {
  background-color: var(--mat-list-list-item-hover-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}

.mdc-list-item.mdc-list-item--disabled::before {
  background-color: var(--mat-list-list-item-disabled-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}

.mdc-list-item:focus::before {
  background-color: var(--mat-list-list-item-focus-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}

.mdc-list-item--disabled .mdc-radio,
.mdc-list-item--disabled .mdc-checkbox {
  opacity: var(--mat-list-list-item-disabled-label-text-opacity, 0.3);
}

.mdc-list-item--with-leading-avatar .mat-mdc-list-item-avatar {
  border-radius: var(--mat-list-list-item-leading-avatar-shape, var(--mat-sys-corner-full));
  background-color: var(--mat-list-list-item-leading-avatar-color, var(--mat-sys-primary-container));
}

.mat-mdc-list-item-icon {
  font-size: var(--mat-list-list-item-leading-icon-size, 24px);
}

@media (forced-colors: active) {
  a.mdc-list-item--activated::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  a.mdc-list-item--activated [dir=rtl]::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-list-base {
  display: block;
}
.mat-mdc-list-base .mdc-list-item__start,
.mat-mdc-list-base .mdc-list-item__end,
.mat-mdc-list-base .mdc-list-item__content {
  pointer-events: auto;
}

.mat-mdc-list-item,
.mat-mdc-list-option {
  width: 100%;
  box-sizing: border-box;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-list-item:not(.mat-mdc-list-item-interactive),
.mat-mdc-list-option:not(.mat-mdc-list-item-interactive) {
  cursor: default;
}
.mat-mdc-list-item .mat-divider-inset,
.mat-mdc-list-option .mat-divider-inset {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
}
.mat-mdc-list-item .mat-mdc-list-item-avatar ~ .mat-divider-inset,
.mat-mdc-list-option .mat-mdc-list-item-avatar ~ .mat-divider-inset {
  margin-left: 72px;
}
[dir=rtl] .mat-mdc-list-item .mat-mdc-list-item-avatar ~ .mat-divider-inset,
[dir=rtl] .mat-mdc-list-option .mat-mdc-list-item-avatar ~ .mat-divider-inset {
  margin-right: 72px;
}

.mat-mdc-list-item-interactive::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  content: "";
  opacity: 0;
  pointer-events: none;
  border-radius: inherit;
}

.mat-mdc-list-item > .mat-focus-indicator {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-list-item:focus-visible > .mat-focus-indicator::before {
  content: "";
}

.mat-mdc-list-item.mdc-list-item--with-three-lines .mat-mdc-list-item-line.mdc-list-item__secondary-text {
  white-space: nowrap;
  line-height: normal;
}
.mat-mdc-list-item.mdc-list-item--with-three-lines .mat-mdc-list-item-unscoped-content.mdc-list-item__secondary-text {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

mat-action-list button {
  background: none;
  color: inherit;
  border: none;
  font: inherit;
  outline: inherit;
  -webkit-tap-highlight-color: transparent;
  text-align: start;
}
mat-action-list button::-moz-focus-inner {
  border: 0;
}

.mdc-list-item--with-leading-icon .mdc-list-item__start {
  margin-inline-start: var(--mat-list-list-item-leading-icon-start-space, 16px);
  margin-inline-end: var(--mat-list-list-item-leading-icon-end-space, 16px);
}

.mat-mdc-nav-list .mat-mdc-list-item {
  border-radius: var(--mat-list-active-indicator-shape, var(--mat-sys-corner-full));
  --mat-focus-indicator-border-radius: var(--mat-list-active-indicator-shape, var(--mat-sys-corner-full));
}
.mat-mdc-nav-list .mat-mdc-list-item.mdc-list-item--activated {
  background-color: var(--mat-list-active-indicator-color, var(--mat-sys-secondary-container));
}
`,oe=["unscopedContent"],ce=["text"],le=[[["","matListItemAvatar",""],["","matListItemIcon",""]],[["","matListItemTitle",""]],[["","matListItemLine",""]],"*",[["","matListItemMeta",""]],[["mat-divider"]]],re=["[matListItemAvatar],[matListItemIcon]","[matListItemTitle]","[matListItemLine]","*","[matListItemMeta]","mat-divider"];var se=new N("ListOption"),U=(()=>{class e{_elementRef=g(F);constructor(){}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,selectors:[["","matListItemTitle",""]],hostAttrs:[1,"mat-mdc-list-item-title","mdc-list-item__primary-text"]})}return e})(),me=(()=>{class e{_elementRef=g(F);constructor(){}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,selectors:[["","matListItemLine",""]],hostAttrs:[1,"mat-mdc-list-item-line","mdc-list-item__secondary-text"]})}return e})(),de=(()=>{class e{static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,selectors:[["","matListItemMeta",""]],hostAttrs:[1,"mat-mdc-list-item-meta","mdc-list-item__end"]})}return e})(),Yt=(()=>{class e{_listOption=g(se,{optional:!0});constructor(){}_isAlignedAtStart(){return!this._listOption||this._listOption?._getTogglePosition()==="after"}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,hostVars:4,hostBindings:function(i,n){i&2&&C("mdc-list-item__start",n._isAlignedAtStart())("mdc-list-item__end",!n._isAlignedAtStart())}})}return e})(),pe=(()=>{class e extends Yt{static \u0275fac=(()=>{let t;return function(n){return(t||(t=O(e)))(n||e)}})();static \u0275dir=u({type:e,selectors:[["","matListItemAvatar",""]],hostAttrs:[1,"mat-mdc-list-item-avatar"],features:[E]})}return e})(),$=(()=>{class e extends Yt{static \u0275fac=(()=>{let t;return function(n){return(t||(t=O(e)))(n||e)}})();static \u0275dir=u({type:e,selectors:[["","matListItemIcon",""]],hostAttrs:[1,"mat-mdc-list-item-icon"],features:[E]})}return e})(),he=new N("MAT_LIST_CONFIG"),G=(()=>{class e{_isNonInteractive=!0;get disableRipple(){return this._disableRipple}set disableRipple(t){this._disableRipple=L(t)}_disableRipple=!1;get disabled(){return this._disabled()}set disabled(t){this._disabled.set(L(t))}_disabled=j(!1);_defaultOptions=g(he,{optional:!0});static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,hostVars:1,hostBindings:function(i,n){i&2&&R("aria-disabled",n.disabled)},inputs:{disableRipple:"disableRipple",disabled:"disabled"}})}return e})(),_e=(()=>{class e{_elementRef=g(F);_ngZone=g(tt);_listBase=g(G,{optional:!0});_platform=g(ut);_hostElement;_isButtonElement;_noopAnimations=ft();_avatars;_icons;set lines(t){this._explicitLines=wt(t,null),this._updateItemLines(!1)}_explicitLines=null;get disableRipple(){return this.disabled||this._disableRipple||this._noopAnimations||!!this._listBase?.disableRipple}set disableRipple(t){this._disableRipple=L(t)}_disableRipple=!1;get disabled(){return this._disabled()||!!this._listBase?.disabled}set disabled(t){this._disabled.set(L(t))}_disabled=j(!1);_subscriptions=new K;_rippleRenderer=null;_hasUnscopedTextContent=!1;rippleConfig;get rippleDisabled(){return this.disableRipple||!!this.rippleConfig.disabled}constructor(){g(vt).load(It);let t=g(St,{optional:!0});this.rippleConfig=t||{},this._hostElement=this._elementRef.nativeElement,this._isButtonElement=this._hostElement.nodeName.toLowerCase()==="button",this._listBase&&!this._listBase._isNonInteractive&&this._initInteractiveListItem(),this._isButtonElement&&!this._hostElement.hasAttribute("type")&&this._hostElement.setAttribute("type","button")}ngAfterViewInit(){this._monitorProjectedLinesAndTitle(),this._updateItemLines(!0)}ngOnDestroy(){this._subscriptions.unsubscribe(),this._rippleRenderer!==null&&this._rippleRenderer._removeTriggerEvents()}_hasIconOrAvatar(){return!!(this._avatars.length||this._icons.length)}_initInteractiveListItem(){this._hostElement.classList.add("mat-mdc-list-item-interactive"),this._rippleRenderer=new Mt(this,this._ngZone,this._hostElement,this._platform,g(J)),this._rippleRenderer.setupTriggerEvents(this._hostElement)}_monitorProjectedLinesAndTitle(){this._ngZone.runOutsideAngular(()=>{this._subscriptions.add(Z(this._lines.changes,this._titles.changes).subscribe(()=>this._updateItemLines(!1)))})}_updateItemLines(t){if(!this._lines||!this._titles||!this._unscopedContent)return;t&&this._checkDomForUnscopedTextContent();let i=this._explicitLines??this._inferLinesFromContent(),n=this._unscopedContent.nativeElement;if(this._hostElement.classList.toggle("mat-mdc-list-item-single-line",i<=1),this._hostElement.classList.toggle("mdc-list-item--with-one-line",i<=1),this._hostElement.classList.toggle("mdc-list-item--with-two-lines",i===2),this._hostElement.classList.toggle("mdc-list-item--with-three-lines",i===3),this._hasUnscopedTextContent){let s=this._titles.length===0&&i===1;n.classList.toggle("mdc-list-item__primary-text",s),n.classList.toggle("mdc-list-item__secondary-text",!s)}else n.classList.remove("mdc-list-item__primary-text"),n.classList.remove("mdc-list-item__secondary-text")}_inferLinesFromContent(){let t=this._titles.length+this._lines.length;return this._hasUnscopedTextContent&&(t+=1),t}_checkDomForUnscopedTextContent(){this._hasUnscopedTextContent=Array.from(this._unscopedContent.nativeElement.childNodes).filter(t=>t.nodeType!==t.COMMENT_NODE).some(t=>!!(t.textContent&&t.textContent.trim()))}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,contentQueries:function(i,n,s){if(i&1&&H(s,pe,4)(s,$,4),i&2){let h;w(h=y())&&(n._avatars=h),w(h=y())&&(n._icons=h)}},hostVars:4,hostBindings:function(i,n){i&2&&(R("aria-disabled",n.disabled)("disabled",n._isButtonElement&&n.disabled||null),C("mdc-list-item--disabled",n.disabled))},inputs:{lines:"lines",disableRipple:"disableRipple",disabled:"disabled"}})}return e})();var Jt=(()=>{class e extends G{static \u0275fac=(()=>{let t;return function(n){return(t||(t=O(e)))(n||e)}})();static \u0275cmp=A({type:e,selectors:[["mat-list"]],hostAttrs:[1,"mat-mdc-list","mat-mdc-list-base","mdc-list"],exportAs:["matList"],features:[it([{provide:G,useExisting:e}]),E],ngContentSelectors:ne,decls:1,vars:0,template:function(i,n){i&1&&(V(),k(0))},styles:[ae],encapsulation:2,changeDetection:0})}return e})(),te=(()=>{class e extends _e{_lines;_titles;_meta;_unscopedContent;_itemText;get activated(){return this._activated}set activated(t){this._activated=L(t)}_activated=!1;_getAriaCurrent(){return this._hostElement.nodeName==="A"&&this._activated?"page":null}_hasBothLeadingAndTrailing(){return this._meta.length!==0&&(this._avatars.length!==0||this._icons.length!==0)}static \u0275fac=(()=>{let t;return function(n){return(t||(t=O(e)))(n||e)}})();static \u0275cmp=A({type:e,selectors:[["mat-list-item"],["a","mat-list-item",""],["button","mat-list-item",""]],contentQueries:function(i,n,s){if(i&1&&H(s,me,5)(s,U,5)(s,de,5),i&2){let h;w(h=y())&&(n._lines=h),w(h=y())&&(n._titles=h),w(h=y())&&(n._meta=h)}},viewQuery:function(i,n){if(i&1&&et(oe,5)(ce,5),i&2){let s;w(s=y())&&(n._unscopedContent=s.first),w(s=y())&&(n._itemText=s.first)}},hostAttrs:[1,"mat-mdc-list-item","mdc-list-item"],hostVars:13,hostBindings:function(i,n){i&2&&(R("aria-current",n._getAriaCurrent()),C("mdc-list-item--activated",n.activated)("mdc-list-item--with-leading-avatar",n._avatars.length!==0)("mdc-list-item--with-leading-icon",n._icons.length!==0)("mdc-list-item--with-trailing-meta",n._meta.length!==0)("mat-mdc-list-item-both-leading-and-trailing",n._hasBothLeadingAndTrailing())("_mat-animation-noopable",n._noopAnimations))},inputs:{activated:"activated"},exportAs:["matListItem"],features:[E],ngContentSelectors:re,decls:10,vars:0,consts:[["unscopedContent",""],[1,"mdc-list-item__content"],[1,"mat-mdc-list-item-unscoped-content",3,"cdkObserveContent"],[1,"mat-focus-indicator"]],template:function(i,n){i&1&&(V(le),k(0),a(1,"span",1),k(2,1),k(3,2),a(4,"span",2,0),b("cdkObserveContent",function(){return n._updateItemLines(!0)}),k(6,3),o()(),k(7,4),k(8,5),f(9,"div",3))},dependencies:[yt],encapsulation:2,changeDetection:0})}return e})();function ge(e,l){if(e&1){let t=P();a(0,"mat-list-item",18),b("click",function(){let n=M(t).$implicit,s=p();return S(s.selectTopic(n))}),a(1,"mat-icon",19),c(2,"data_object"),o(),a(3,"span",20),c(4),o()()}if(e&2){let t=l.$implicit,i=p();C("selected-topic",t===i.selectedTopic),r(),m("ngClass","topic-icon-"+t.replace("-","_")),r(3),_(t)}}function be(e,l){if(e&1&&(a(0,"span",21),c(1),o()),e&2){let t=l.$implicit;r(),_(t)}}function ue(e,l){if(e&1&&(a(0,"mat-option",37),c(1),o()),e&2){let t=l.$implicit;m("value",t),r(),_(t)}}function fe(e,l){if(e&1&&(a(0,"mat-option",37),c(1),o()),e&2){let t=l.$implicit;m("value",t),r(),_(t)}}function xe(e,l){if(e&1&&(a(0,"mat-option",37),c(1),o()),e&2){let t=l.$implicit;m("value",t),r(),_(t)}}function ve(e,l){if(e&1&&(a(0,"mat-option",37)(1,"mat-icon",38),c(2),o(),c(3),o()),e&2){let t=l.$implicit,i=p(2);m("value",t.value),r(2),_(i.chartRoleIcons[t.value]),r(),I(" ",t.label," ")}}function ke(e,l){if(e&1){let t=P();a(0,"div",22)(1,"div",23),c(2),o(),a(3,"form",24)(4,"mat-form-field",25)(5,"mat-label"),c(6,"Source Field"),o(),a(7,"mat-select",26),d(8,ue,2,2,"mat-option",27),o()(),a(9,"mat-form-field",25)(10,"mat-label"),c(11,"FAME Series Name"),o(),f(12,"input",28),o(),a(13,"mat-form-field",25)(14,"mat-label"),c(15,"Data Type"),o(),a(16,"mat-select",29),d(17,fe,2,2,"mat-option",27),o()(),a(18,"mat-form-field",25)(19,"mat-label"),c(20,"Aggregation"),o(),a(21,"mat-select",30),d(22,xe,2,2,"mat-option",27),o()(),a(23,"mat-form-field",25)(24,"mat-label"),c(25,"Chart Role"),o(),a(26,"mat-select",31),d(27,ve,4,3,"mat-option",27),o(),a(28,"mat-hint"),c(29,"Which price slot this field fills on the chart (OHLCV)"),o()(),a(30,"mat-form-field",25)(31,"mat-label"),c(32,"Description"),o(),f(33,"input",32),o(),a(34,"mat-slide-toggle",33),b("change",function(n){let s;M(t);let h=p();return S((s=h.form.get("active"))==null?null:s.setValue(n.checked?1:0))}),c(35," Active "),o(),a(36,"div",34)(37,"button",35),b("click",function(){M(t);let n=p();return S(n.cancelForm())}),c(38,"Cancel"),o(),a(39,"button",36),b("click",function(){M(t);let n=p();return S(n.save())}),c(40),o()()()()}if(e&2){let t,i=p();r(2),_(i.editingId?"Edit Mapping":"New Mapping"),r(),m("formGroup",i.form),r(5),m("ngForOf",i.availableFields),r(9),m("ngForOf",i.dataTypes),r(5),m("ngForOf",i.aggregations),r(5),m("ngForOf",i.chartRoles),r(7),m("checked",((t=i.form.get("active"))==null?null:t.value)===1),r(5),m("disabled",i.form.invalid),r(),I(" ",i.editingId?"Update":"Create"," ")}}function we(e,l){e&1&&(a(0,"div",39),f(1,"mat-spinner",40),o())}function ye(e,l){if(e&1&&(a(0,"div",41),c(1),o()),e&2){let t=p();r(),I(" No mappings defined for ",t.selectedTopic,'. Click "Add Mapping" to create one. ')}}function Ce(e,l){e&1&&(a(0,"th",54),c(1,"Source Field"),o())}function Me(e,l){if(e&1&&(a(0,"td",55),c(1),o()),e&2){let t=l.$implicit;r(),_(t.sourceField)}}function Se(e,l){e&1&&(a(0,"th",54),c(1,"Chart Role"),o())}function Ie(e,l){if(e&1&&(a(0,"td",55)(1,"span",56)(2,"mat-icon",57),c(3),o(),c(4),o()()),e&2){let t=l.$implicit,i=p(2);r(),C("role-active",i.isChartMapped(t.chartRole)),r(2),_(i.chartRoleIcon(t.chartRole)),r(),I(" ",i.chartRoleLabel(t.chartRole)," ")}}function Le(e,l){e&1&&(a(0,"th",54),c(1,"FAME Series"),o())}function Oe(e,l){if(e&1&&(a(0,"td",55),c(1),o()),e&2){let t=l.$implicit;r(),_(t.fameSeriesName)}}function Ae(e,l){e&1&&(a(0,"th",54),c(1,"Type"),o())}function Ee(e,l){if(e&1&&(a(0,"td",55),c(1),o()),e&2){let t=l.$implicit;r(),_(t.dataType)}}function Te(e,l){e&1&&(a(0,"th",54),c(1,"Aggregation"),o())}function De(e,l){if(e&1&&(a(0,"td",55),c(1),o()),e&2){let t=l.$implicit;r(),_(t.aggregation)}}function Fe(e,l){e&1&&(a(0,"th",54),c(1,"Active"),o())}function ze(e,l){if(e&1&&(a(0,"td",55)(1,"span",58),c(2),o()()),e&2){let t=l.$implicit;r(),C("badge-active",t.active===1)("badge-inactive",t.active!==1),r(),I(" ",t.active===1?"Yes":"No"," ")}}function Re(e,l){e&1&&(a(0,"th",54),c(1,"Actions"),o())}function Pe(e,l){if(e&1){let t=P();a(0,"td",55)(1,"button",59),b("click",function(){let n=M(t).$implicit,s=p(2);return S(s.openEditForm(n))}),a(2,"mat-icon"),c(3,"edit"),o()(),a(4,"button",60),b("click",function(){let n=M(t).$implicit,s=p(2);return S(s.delete(n))}),a(5,"mat-icon"),c(6,"delete"),o()()()}}function Ne(e,l){e&1&&f(0,"tr",61)}function Be(e,l){e&1&&f(0,"tr",62)}function je(e,l){if(e&1&&(a(0,"table",42),x(1,43),d(2,Ce,2,0,"th",44)(3,Me,2,1,"td",45),v(),x(4,46),d(5,Se,2,0,"th",44)(6,Ie,5,4,"td",45),v(),x(7,47),d(8,Le,2,0,"th",44)(9,Oe,2,1,"td",45),v(),x(10,48),d(11,Ae,2,0,"th",44)(12,Ee,2,1,"td",45),v(),x(13,49),d(14,Te,2,0,"th",44)(15,De,2,1,"td",45),v(),x(16,50),d(17,Fe,2,0,"th",44)(18,ze,3,5,"td",45),v(),x(19,51),d(20,Re,2,0,"th",44)(21,Pe,7,0,"td",45),v(),d(22,Ne,1,0,"tr",52)(23,Be,1,0,"tr",53),o()),e&2){let t=p();m("dataSource",t.mappings),r(22),m("matHeaderRowDef",t.displayedColumns),r(),m("matRowDefColumns",t.displayedColumns)}}var ee={"market-data":["vwap","daily_high","daily_low","daily_volume","bid_volume","ask_volume","latency_us","price_change_pct","tick_id","liquidity_provider","quote_source","is_indicative","market_depth"],"pre-trade":["trader_id","order_id","order_type","side","counterparty","order_status","time_in_force","algorithm","settlement_type","limit_price","risk_check_passed","requested_volume","quote_ttl_ms","client_order_ref","settlement_date"],"post-trade":["trade_id","trader_id","side","counterparty","executed_price","executed_volume","execution_time_ms","slippage_bps","pnl_usd","fees_usd","trade_status","settlement_type","settlement_date","clearing_house","confirmation_id","order_id"]},q=["market-data","pre-trade","post-trade"],Ve=["DOUBLE","INTEGER","STRING","BOOLEAN"],He=["LAST","FIRST","SUM","AVG","MIN","MAX","COUNT"],Qe={NONE:"block",MID:"show_chart",OPEN:"start",HIGH:"arrow_upward",LOW:"arrow_downward",CLOSE:"last_page",VOLUME:"bar_chart"},Gi=(()=>{class e{mappingService;fb;snackBar;topics=q;selectedTopic=q[0];availableFields=ee[q[0]];dataTypes=Ve;aggregations=He;mappings=[];chartRoles=Kt;chartRoleIcons=Qe;displayedColumns=["sourceField","chartRole","fameSeriesName","dataType","aggregation","active","actions"];loading=!1;showForm=!1;editingId=null;form;constructor(t,i,n){this.mappingService=t,this.fb=i,this.snackBar=n,this.form=this.fb.group({sourceField:["",Q.required],fameSeriesName:["",Q.required],dataType:["DOUBLE"],aggregation:["LAST"],active:[1],description:[""],chartRole:["NONE"]})}ngOnInit(){this.loadMappings()}selectTopic(t){this.selectedTopic=t,this.availableFields=ee[t]||[],this.showForm=!1,this.editingId=null,this.loadMappings()}loadMappings(){this.loading=!0,this.mappingService.getAll(this.selectedTopic).pipe(D(()=>T([]))).subscribe(t=>{this.mappings=t,this.loading=!1})}openAddForm(){this.editingId=null,this.form.reset({dataType:"DOUBLE",aggregation:"LAST",active:1,chartRole:"NONE"}),this.showForm=!0}chartRoleLabel(t){return this.chartRoles.find(i=>i.value===t)?.label??"Not on chart"}chartRoleIcon(t){return this.chartRoleIcons[t??"NONE"]??"block"}isChartMapped(t){return!!t&&t!=="NONE"}openEditForm(t){this.editingId=t.id??null,this.form.patchValue(t),this.showForm=!0}cancelForm(){this.showForm=!1,this.editingId=null}save(){if(this.form.invalid)return;let t=X(W({},this.form.value),{topicName:this.selectedTopic});(this.editingId?this.mappingService.update(this.editingId,t):this.mappingService.create(t)).pipe(D(n=>(this.snackBar.open("Save failed: "+(n.message||"Unknown error"),"Close",{duration:3e3}),T(null)))).subscribe(n=>{n&&(this.snackBar.open("Saved successfully","Close",{duration:2e3}),this.showForm=!1,this.editingId=null,this.loadMappings())})}delete(t){t.id&&confirm(`Delete mapping "${t.sourceField} \u2192 ${t.fameSeriesName}"?`)&&this.mappingService.delete(t.id).pipe(D(i=>(this.snackBar.open("Delete failed","Close",{duration:3e3}),T(null)))).subscribe(()=>{this.snackBar.open("Deleted","Close",{duration:2e3}),this.loadMappings()})}static \u0275fac=function(i){return new(i||e)(z(Zt),z(_t),z(Wt))};static \u0275cmp=A({type:e,selectors:[["app-attribute-mapping"]],decls:27,vars:6,consts:[[1,"am-page"],[1,"am-header"],[1,"am-header-icon"],[1,"spacer"],["mat-raised-button","","color","primary",3,"click"],[1,"am-layout"],[1,"am-left-panel"],[1,"panel-title"],["class","topic-item",3,"selected-topic","click",4,"ngFor","ngForOf"],[1,"panel-title","field-title"],[1,"field-list"],["class","field-chip",4,"ngFor","ngForOf"],[1,"am-right-panel"],["class","am-form-card",4,"ngIf"],[1,"table-card"],["class","loading-row",4,"ngIf"],["class","empty-state",4,"ngIf"],["mat-table","","class","am-table",3,"dataSource",4,"ngIf"],[1,"topic-item",3,"click"],["matListItemIcon","",3,"ngClass"],["matListItemTitle",""],[1,"field-chip"],[1,"am-form-card"],[1,"form-title"],[1,"am-form",3,"formGroup"],["appearance","outline"],["formControlName","sourceField"],[3,"value",4,"ngFor","ngForOf"],["matInput","","formControlName","fameSeriesName","placeholder","e.g. FX.EURUSD.VWAP"],["formControlName","dataType"],["formControlName","aggregation"],["formControlName","chartRole"],["matInput","","formControlName","description"],["formControlName","active",3,"change","checked"],[1,"form-actions"],["mat-button","",3,"click"],["mat-raised-button","","color","primary",3,"click","disabled"],[3,"value"],[2,"vertical-align","middle","font-size","16px","margin-right","6px"],[1,"loading-row"],["diameter","32"],[1,"empty-state"],["mat-table","",1,"am-table",3,"dataSource"],["matColumnDef","sourceField"],["mat-header-cell","",4,"matHeaderCellDef"],["mat-cell","",4,"matCellDef"],["matColumnDef","chartRole"],["matColumnDef","fameSeriesName"],["matColumnDef","dataType"],["matColumnDef","aggregation"],["matColumnDef","active"],["matColumnDef","actions"],["mat-header-row","",4,"matHeaderRowDef"],["mat-row","",4,"matRowDef","matRowDefColumns"],["mat-header-cell",""],["mat-cell",""],[1,"role-badge"],[1,"role-icon"],[1,"status-badge"],["mat-icon-button","","color","primary","matTooltip","Edit",3,"click"],["mat-icon-button","","color","warn","matTooltip","Delete",3,"click"],["mat-header-row",""],["mat-row",""]],template:function(i,n){i&1&&(a(0,"div",0)(1,"div",1)(2,"mat-icon",2),c(3,"swap_horiz"),o(),a(4,"h2"),c(5,"Attribute Mappings"),o(),f(6,"span",3),a(7,"button",4),b("click",function(){return n.openAddForm()}),a(8,"mat-icon"),c(9,"add"),o(),c(10," Add Mapping "),o()(),a(11,"div",5)(12,"div",6)(13,"div",7),c(14,"Topics"),o(),a(15,"mat-list"),d(16,ge,5,4,"mat-list-item",8),o(),a(17,"div",9),c(18,"Known Fields"),o(),a(19,"div",10),d(20,be,2,1,"span",11),o()(),a(21,"div",12),d(22,ke,41,9,"div",13),a(23,"div",14),d(24,we,2,0,"div",15)(25,ye,2,1,"div",16)(26,je,24,3,"table",17),o()()()()),i&2&&(r(16),m("ngForOf",n.topics),r(4),m("ngForOf",n.availableFields),r(2),m("ngIf",n.showForm),r(2),m("ngIf",n.loading),r(),m("ngIf",!n.loading&&n.mappings.length===0),r(),m("ngIf",!n.loading&&n.mappings.length>0))},dependencies:[kt,Ot,Jt,at,te,$,nt,U,ot,gt,dt,rt,st,mt,bt,ht,pt,Qt,Vt,Ht,$t,Ut,Gt,qt,xt,At,Dt,Tt,Ft,Et,zt,Lt,Ct,Rt,Nt,Pt,Bt],styles:[".am-page[_ngcontent-%COMP%]{padding:24px;background:#f5f5f5;min-height:100vh}.am-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;margin-bottom:24px}.am-header-icon[_ngcontent-%COMP%]{color:#1976d2;font-size:28px}.am-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;font-size:22px;font-weight:600;color:#333}.spacer[_ngcontent-%COMP%]{flex:1}.am-layout[_ngcontent-%COMP%]{display:flex;gap:16px}.am-left-panel[_ngcontent-%COMP%]{width:240px;min-width:200px;background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:12px 0}.panel-title[_ngcontent-%COMP%]{font-size:11px;font-weight:600;text-transform:uppercase;color:#888;padding:8px 16px 4px;letter-spacing:.5px}.field-title[_ngcontent-%COMP%]{margin-top:12px;border-top:1px solid #e0e0e0}.topic-item[_ngcontent-%COMP%]{cursor:pointer}.topic-item[_ngcontent-%COMP%]:hover{background:#f5f5f5}.topic-item.selected-topic[_ngcontent-%COMP%]{background:#e3f2fd;color:#1976d2}.field-list[_ngcontent-%COMP%]{padding:8px 12px;display:flex;flex-wrap:wrap;gap:6px}.field-chip[_ngcontent-%COMP%]{background:#f0f4ff;border:1px solid #c5d8f0;border-radius:12px;padding:2px 8px;font-size:11px;color:#1976d2}.am-right-panel[_ngcontent-%COMP%]{flex:1;display:flex;flex-direction:column;gap:16px}.am-form-card[_ngcontent-%COMP%]{background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:20px}.form-title[_ngcontent-%COMP%]{font-size:15px;font-weight:600;color:#333;margin-bottom:16px}.am-form[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:12px}.am-form[_ngcontent-%COMP%]   mat-form-field[_ngcontent-%COMP%]{width:100%}.am-form[_ngcontent-%COMP%]   mat-slide-toggle[_ngcontent-%COMP%]{align-self:center}.form-actions[_ngcontent-%COMP%]{grid-column:1/-1;display:flex;gap:8px;justify-content:flex-end}.table-card[_ngcontent-%COMP%]{background:#fff;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden}.am-table[_ngcontent-%COMP%]{width:100%}.am-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{background:#f5f5f5;font-weight:600;color:#555}.loading-row[_ngcontent-%COMP%], .empty-state[_ngcontent-%COMP%]{padding:40px;text-align:center;color:#888}.status-badge[_ngcontent-%COMP%]{padding:2px 10px;border-radius:12px;font-size:12px;font-weight:500}.status-badge.badge-active[_ngcontent-%COMP%]{background:#e8f5e9;color:#388e3c}.status-badge.badge-inactive[_ngcontent-%COMP%]{background:#fafafa;color:#999;border:1px solid #e0e0e0}.role-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:12px;font-size:12px;background:#f5f5f5;color:#999;border:1px solid #e0e0e0}.role-badge[_ngcontent-%COMP%]   .role-icon[_ngcontent-%COMP%]{font-size:14px;width:14px;height:14px;line-height:14px}.role-badge.role-active[_ngcontent-%COMP%]{background:#e8f0fe;color:#1565c0;border-color:#bbdefb;font-weight:500}"]})}return e})();export{Gi as AttributeMappingComponent};
