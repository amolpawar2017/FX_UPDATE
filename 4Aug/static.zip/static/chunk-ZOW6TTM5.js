import"./chunk-BCCDUILC.js";import{b as $t}from"./chunk-PX3UZRRK.js";import{a as xt}from"./chunk-HDFBS7AW.js";import{b as Tt,c as Ot,d as Et,e as Dt,f as Ft,g as zt,h as Pt,i as Rt,j as Bt,k as Nt}from"./chunk-JAO5EW2C.js";import{a as Ht}from"./chunk-3D3FRWOZ.js";import{a as qt}from"./chunk-U4YX2DQY.js";import{d as Vt,k as Qt,m as Gt,n as Ut}from"./chunk-PNTILEUX.js";import{b as lt,d as H,f as rt,g as mt,j as dt,l as ht,m as pt,p as _t,q as gt,r as bt}from"./chunk-5AU5NM3W.js";import{a as Ct}from"./chunk-BHI5CEHR.js";import"./chunk-X6W5R2HS.js";import{a as ut,f as ft,i as vt,k as kt,la as Mt,m as wt,ma as St,p as I,pa as It,qa as At,sa as Lt,y as yt}from"./chunk-VJULX6IE.js";import{a as jt}from"./chunk-254FYNHO.js";import{d as nt,e as at,f as ot,u as ct,v as st}from"./chunk-FYW6F2XK.js";import{$a as l,$b as V,Da as A,Db as z,Fa as D,H as Z,K as E,Kb as m,Lb as a,Mb as o,Nb as f,Rb as C,Sb as M,Ub as P,Yb as b,_b as _,a as X,ac as x,b as K,bc as Q,ca as Y,cc as et,dc as v,ec as k,fa as B,ga as N,h as W,ha as p,ib as F,kc as S,ma as w,mc as c,na as y,nc as g,ob as L,oc as R,qa as J,qb as u,s as O,tb as T,ub as d,va as tt,vc as it,ya as j}from"./chunk-OYT7HEGD.js";var te=["*"],ee=`.mdc-list {
  margin: 0;
  padding: 8px 0;
  list-style-type: none;
}
.mdc-list:focus {
  outline: none;
}

.mdc-list-item {
  display: flex;
  position: relative;
  justify-content: flex-start;
  overflow: hidden;
  padding: 0;
  align-items: stretch;
  cursor: pointer;
  padding-left: 16px;
  padding-right: 16px;
  background-color: var(--mat-list-list-item-container-color, transparent);
  border-radius: var(--mat-list-list-item-container-shape, var(--mat-sys-corner-none));
}
.mdc-list-item.mdc-list-item--selected {
  background-color: var(--mat-list-list-item-selected-container-color);
}
.mdc-list-item:focus {
  outline: 0;
}
.mdc-list-item.mdc-list-item--disabled {
  cursor: auto;
}
.mdc-list-item.mdc-list-item--with-one-line {
  height: var(--mat-list-list-item-one-line-container-height, 48px);
}
.mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__start {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-one-line .mdc-list-item__end {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-two-lines {
  height: var(--mat-list-list-item-two-line-container-height, 64px);
}
.mdc-list-item.mdc-list-item--with-two-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--with-two-lines .mdc-list-item__end {
  align-self: center;
  margin-top: 0;
}
.mdc-list-item.mdc-list-item--with-three-lines {
  height: var(--mat-list-list-item-three-line-container-height, 88px);
}
.mdc-list-item.mdc-list-item--with-three-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--with-three-lines .mdc-list-item__end {
  align-self: flex-start;
  margin-top: 16px;
}
.mdc-list-item.mdc-list-item--selected::before, .mdc-list-item.mdc-list-item--selected:focus::before, .mdc-list-item:not(.mdc-list-item--selected):focus::before {
  position: absolute;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  content: "";
  pointer-events: none;
}

a.mdc-list-item {
  color: inherit;
  text-decoration: none;
}

.mdc-list-item__start {
  fill: currentColor;
  flex-shrink: 0;
  pointer-events: none;
}
.mdc-list-item--with-leading-icon .mdc-list-item__start {
  color: var(--mat-list-list-item-leading-icon-color, var(--mat-sys-on-surface-variant));
  width: var(--mat-list-list-item-leading-icon-size, 24px);
  height: var(--mat-list-list-item-leading-icon-size, 24px);
  margin-left: 16px;
  margin-right: 32px;
}
[dir=rtl] .mdc-list-item--with-leading-icon .mdc-list-item__start {
  margin-left: 32px;
  margin-right: 16px;
}
.mdc-list-item--with-leading-icon:hover .mdc-list-item__start {
  color: var(--mat-list-list-item-hover-leading-icon-color);
}
.mdc-list-item--with-leading-avatar .mdc-list-item__start {
  width: var(--mat-list-list-item-leading-avatar-size, 40px);
  height: var(--mat-list-list-item-leading-avatar-size, 40px);
  margin-left: 16px;
  margin-right: 16px;
  border-radius: 50%;
}
.mdc-list-item--with-leading-avatar .mdc-list-item__start, [dir=rtl] .mdc-list-item--with-leading-avatar .mdc-list-item__start {
  margin-left: 16px;
  margin-right: 16px;
  border-radius: 50%;
}

.mdc-list-item__end {
  flex-shrink: 0;
  pointer-events: none;
}
.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  font-family: var(--mat-list-list-item-trailing-supporting-text-font, var(--mat-sys-label-small-font));
  line-height: var(--mat-list-list-item-trailing-supporting-text-line-height, var(--mat-sys-label-small-line-height));
  font-size: var(--mat-list-list-item-trailing-supporting-text-size, var(--mat-sys-label-small-size));
  font-weight: var(--mat-list-list-item-trailing-supporting-text-weight, var(--mat-sys-label-small-weight));
  letter-spacing: var(--mat-list-list-item-trailing-supporting-text-tracking, var(--mat-sys-label-small-tracking));
}
.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-trailing-icon-color, var(--mat-sys-on-surface-variant));
  width: var(--mat-list-list-item-trailing-icon-size, 24px);
  height: var(--mat-list-list-item-trailing-icon-size, 24px);
}
.mdc-list-item--with-trailing-icon:hover .mdc-list-item__end {
  color: var(--mat-list-list-item-hover-trailing-icon-color);
}
.mdc-list-item.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  color: var(--mat-list-list-item-trailing-supporting-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-list-item--selected.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-selected-trailing-icon-color, var(--mat-sys-primary));
}

.mdc-list-item__content {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  align-self: center;
  flex: 1;
  pointer-events: none;
}
.mdc-list-item--with-two-lines .mdc-list-item__content, .mdc-list-item--with-three-lines .mdc-list-item__content {
  align-self: stretch;
}

.mdc-list-item__primary-text {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  color: var(--mat-list-list-item-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-list-list-item-label-text-font, var(--mat-sys-body-large-font));
  line-height: var(--mat-list-list-item-label-text-line-height, var(--mat-sys-body-large-line-height));
  font-size: var(--mat-list-list-item-label-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-list-list-item-label-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-list-list-item-label-text-tracking, var(--mat-sys-body-large-tracking));
}
.mdc-list-item:hover .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-hover-label-text-color, var(--mat-sys-on-surface));
}
.mdc-list-item:focus .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-focus-label-text-color, var(--mat-sys-on-surface));
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text, .mdc-list-item--with-three-lines .mdc-list-item__primary-text {
  display: block;
  margin-top: 0;
  line-height: normal;
  margin-bottom: -20px;
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before, .mdc-list-item--with-three-lines .mdc-list-item__primary-text::before {
  display: inline-block;
  width: 0;
  height: 28px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after, .mdc-list-item--with-three-lines .mdc-list-item__primary-text::after {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: -20px;
}

.mdc-list-item__secondary-text {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  display: block;
  margin-top: 0;
  color: var(--mat-list-list-item-supporting-text-color, var(--mat-sys-on-surface-variant));
  font-family: var(--mat-list-list-item-supporting-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-list-list-item-supporting-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-list-list-item-supporting-text-size, var(--mat-sys-body-medium-size));
  font-weight: var(--mat-list-list-item-supporting-text-weight, var(--mat-sys-body-medium-weight));
  letter-spacing: var(--mat-list-list-item-supporting-text-tracking, var(--mat-sys-body-medium-tracking));
}
.mdc-list-item__secondary-text::before {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-three-lines .mdc-list-item__secondary-text {
  white-space: normal;
  line-height: 20px;
}
.mdc-list-item--with-overline .mdc-list-item__secondary-text {
  white-space: nowrap;
  line-height: auto;
}

.mdc-list-item--with-leading-radio.mdc-list-item,
.mdc-list-item--with-leading-checkbox.mdc-list-item,
.mdc-list-item--with-leading-icon.mdc-list-item,
.mdc-list-item--with-leading-avatar.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
[dir=rtl] .mdc-list-item--with-leading-radio.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-checkbox.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-icon.mdc-list-item,
[dir=rtl] .mdc-list-item--with-leading-avatar.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text {
  display: block;
  margin-top: 0;
  line-height: normal;
  margin-bottom: -20px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text::before {
  display: inline-block;
  width: 0;
  height: 32px;
  content: "";
  vertical-align: 0;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines .mdc-list-item__primary-text::after {
  display: inline-block;
  width: 0;
  height: 20px;
  content: "";
  vertical-align: -20px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  display: block;
  margin-top: 0;
  line-height: normal;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-icon.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before,
.mdc-list-item--with-leading-avatar.mdc-list-item--with-two-lines.mdc-list-item--with-trailing-meta .mdc-list-item__end::before {
  display: inline-block;
  width: 0;
  height: 32px;
  content: "";
  vertical-align: 0;
}

.mdc-list-item--with-trailing-icon.mdc-list-item, [dir=rtl] .mdc-list-item--with-trailing-icon.mdc-list-item {
  padding-left: 0;
  padding-right: 0;
}
.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  margin-left: 16px;
  margin-right: 16px;
}

.mdc-list-item--with-trailing-meta.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-meta.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
.mdc-list-item--with-trailing-meta .mdc-list-item__end {
  -webkit-user-select: none;
  user-select: none;
  margin-left: 28px;
  margin-right: 16px;
}
[dir=rtl] .mdc-list-item--with-trailing-meta .mdc-list-item__end {
  margin-left: 16px;
  margin-right: 28px;
}
.mdc-list-item--with-trailing-meta.mdc-list-item--with-three-lines .mdc-list-item__end, .mdc-list-item--with-trailing-meta.mdc-list-item--with-two-lines .mdc-list-item__end {
  display: block;
  line-height: normal;
  align-self: flex-start;
  margin-top: 0;
}
.mdc-list-item--with-trailing-meta.mdc-list-item--with-three-lines .mdc-list-item__end::before, .mdc-list-item--with-trailing-meta.mdc-list-item--with-two-lines .mdc-list-item__end::before {
  display: inline-block;
  width: 0;
  height: 28px;
  content: "";
  vertical-align: 0;
}

.mdc-list-item--with-leading-radio .mdc-list-item__start,
.mdc-list-item--with-leading-checkbox .mdc-list-item__start {
  margin-left: 8px;
  margin-right: 24px;
}
[dir=rtl] .mdc-list-item--with-leading-radio .mdc-list-item__start,
[dir=rtl] .mdc-list-item--with-leading-checkbox .mdc-list-item__start {
  margin-left: 24px;
  margin-right: 8px;
}
.mdc-list-item--with-leading-radio.mdc-list-item--with-two-lines .mdc-list-item__start,
.mdc-list-item--with-leading-checkbox.mdc-list-item--with-two-lines .mdc-list-item__start {
  align-self: flex-start;
  margin-top: 8px;
}

.mdc-list-item--with-trailing-radio.mdc-list-item,
.mdc-list-item--with-trailing-checkbox.mdc-list-item {
  padding-left: 16px;
  padding-right: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item {
  padding-left: 0;
  padding-right: 16px;
}
.mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-icon, .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-avatar,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-icon,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-avatar {
  padding-left: 0;
}
[dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-icon, [dir=rtl] .mdc-list-item--with-trailing-radio.mdc-list-item--with-leading-avatar,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-icon,
[dir=rtl] .mdc-list-item--with-trailing-checkbox.mdc-list-item--with-leading-avatar {
  padding-right: 0;
}
.mdc-list-item--with-trailing-radio .mdc-list-item__end,
.mdc-list-item--with-trailing-checkbox .mdc-list-item__end {
  margin-left: 24px;
  margin-right: 8px;
}
[dir=rtl] .mdc-list-item--with-trailing-radio .mdc-list-item__end,
[dir=rtl] .mdc-list-item--with-trailing-checkbox .mdc-list-item__end {
  margin-left: 8px;
  margin-right: 24px;
}
.mdc-list-item--with-trailing-radio.mdc-list-item--with-three-lines .mdc-list-item__end,
.mdc-list-item--with-trailing-checkbox.mdc-list-item--with-three-lines .mdc-list-item__end {
  align-self: flex-start;
  margin-top: 8px;
}

.mdc-list-group__subheader {
  margin: 0.75rem 16px;
}

.mdc-list-item--disabled .mdc-list-item__start,
.mdc-list-item--disabled .mdc-list-item__content,
.mdc-list-item--disabled .mdc-list-item__end {
  opacity: 1;
}
.mdc-list-item--disabled .mdc-list-item__primary-text,
.mdc-list-item--disabled .mdc-list-item__secondary-text {
  opacity: var(--mat-list-list-item-disabled-label-text-opacity, 0.3);
}
.mdc-list-item--disabled.mdc-list-item--with-leading-icon .mdc-list-item__start {
  color: var(--mat-list-list-item-disabled-leading-icon-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-leading-icon-opacity, 0.38);
}
.mdc-list-item--disabled.mdc-list-item--with-trailing-icon .mdc-list-item__end {
  color: var(--mat-list-list-item-disabled-trailing-icon-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-trailing-icon-opacity, 0.38);
}

.mat-mdc-list-item.mat-mdc-list-item-both-leading-and-trailing, [dir=rtl] .mat-mdc-list-item.mat-mdc-list-item-both-leading-and-trailing {
  padding-left: 0;
  padding-right: 0;
}

.mdc-list-item.mdc-list-item--disabled .mdc-list-item__primary-text {
  color: var(--mat-list-list-item-disabled-label-text-color, var(--mat-sys-on-surface));
}

.mdc-list-item:hover::before {
  background-color: var(--mat-list-list-item-hover-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}

.mdc-list-item.mdc-list-item--disabled::before {
  background-color: var(--mat-list-list-item-disabled-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-disabled-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}

.mdc-list-item:focus::before {
  background-color: var(--mat-list-list-item-focus-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-list-list-item-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}

.mdc-list-item--disabled .mdc-radio,
.mdc-list-item--disabled .mdc-checkbox {
  opacity: var(--mat-list-list-item-disabled-label-text-opacity, 0.3);
}

.mdc-list-item--with-leading-avatar .mat-mdc-list-item-avatar {
  border-radius: var(--mat-list-list-item-leading-avatar-shape, var(--mat-sys-corner-full));
  background-color: var(--mat-list-list-item-leading-avatar-color, var(--mat-sys-primary-container));
}

.mat-mdc-list-item-icon {
  font-size: var(--mat-list-list-item-leading-icon-size, 24px);
}

@media (forced-colors: active) {
  a.mdc-list-item--activated::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  a.mdc-list-item--activated [dir=rtl]::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-list-base {
  display: block;
}
.mat-mdc-list-base .mdc-list-item__start,
.mat-mdc-list-base .mdc-list-item__end,
.mat-mdc-list-base .mdc-list-item__content {
  pointer-events: auto;
}

.mat-mdc-list-item,
.mat-mdc-list-option {
  width: 100%;
  box-sizing: border-box;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-list-item:not(.mat-mdc-list-item-interactive),
.mat-mdc-list-option:not(.mat-mdc-list-item-interactive) {
  cursor: default;
}
.mat-mdc-list-item .mat-divider-inset,
.mat-mdc-list-option .mat-divider-inset {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
}
.mat-mdc-list-item .mat-mdc-list-item-avatar ~ .mat-divider-inset,
.mat-mdc-list-option .mat-mdc-list-item-avatar ~ .mat-divider-inset {
  margin-left: 72px;
}
[dir=rtl] .mat-mdc-list-item .mat-mdc-list-item-avatar ~ .mat-divider-inset,
[dir=rtl] .mat-mdc-list-option .mat-mdc-list-item-avatar ~ .mat-divider-inset {
  margin-right: 72px;
}

.mat-mdc-list-item-interactive::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  content: "";
  opacity: 0;
  pointer-events: none;
  border-radius: inherit;
}

.mat-mdc-list-item > .mat-focus-indicator {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-list-item:focus-visible > .mat-focus-indicator::before {
  content: "";
}

.mat-mdc-list-item.mdc-list-item--with-three-lines .mat-mdc-list-item-line.mdc-list-item__secondary-text {
  white-space: nowrap;
  line-height: normal;
}
.mat-mdc-list-item.mdc-list-item--with-three-lines .mat-mdc-list-item-unscoped-content.mdc-list-item__secondary-text {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

mat-action-list button {
  background: none;
  color: inherit;
  border: none;
  font: inherit;
  outline: inherit;
  -webkit-tap-highlight-color: transparent;
  text-align: start;
}
mat-action-list button::-moz-focus-inner {
  border: 0;
}

.mdc-list-item--with-leading-icon .mdc-list-item__start {
  margin-inline-start: var(--mat-list-list-item-leading-icon-start-space, 16px);
  margin-inline-end: var(--mat-list-list-item-leading-icon-end-space, 16px);
}

.mat-mdc-nav-list .mat-mdc-list-item {
  border-radius: var(--mat-list-active-indicator-shape, var(--mat-sys-corner-full));
  --mat-focus-indicator-border-radius: var(--mat-list-active-indicator-shape, var(--mat-sys-corner-full));
}
.mat-mdc-nav-list .mat-mdc-list-item.mdc-list-item--activated {
  background-color: var(--mat-list-active-indicator-color, var(--mat-sys-secondary-container));
}
`,ie=["unscopedContent"],ne=["text"],ae=[[["","matListItemAvatar",""],["","matListItemIcon",""]],[["","matListItemTitle",""]],[["","matListItemLine",""]],"*",[["","matListItemMeta",""]],[["mat-divider"]]],oe=["[matListItemAvatar],[matListItemIcon]","[matListItemTitle]","[matListItemLine]","*","[matListItemMeta]","mat-divider"];var ce=new B("ListOption"),U=(()=>{class e{_elementRef=p(D);constructor(){}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,selectors:[["","matListItemTitle",""]],hostAttrs:[1,"mat-mdc-list-item-title","mdc-list-item__primary-text"]})}return e})(),se=(()=>{class e{_elementRef=p(D);constructor(){}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,selectors:[["","matListItemLine",""]],hostAttrs:[1,"mat-mdc-list-item-line","mdc-list-item__secondary-text"]})}return e})(),le=(()=>{class e{static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,selectors:[["","matListItemMeta",""]],hostAttrs:[1,"mat-mdc-list-item-meta","mdc-list-item__end"]})}return e})(),Kt=(()=>{class e{_listOption=p(ce,{optional:!0});constructor(){}_isAlignedAtStart(){return!this._listOption||this._listOption?._getTogglePosition()==="after"}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,hostVars:4,hostBindings:function(i,n){i&2&&S("mdc-list-item__start",n._isAlignedAtStart())("mdc-list-item__end",!n._isAlignedAtStart())}})}return e})(),re=(()=>{class e extends Kt{static \u0275fac=(()=>{let t;return function(n){return(t||(t=A(e)))(n||e)}})();static \u0275dir=u({type:e,selectors:[["","matListItemAvatar",""]],hostAttrs:[1,"mat-mdc-list-item-avatar"],features:[T]})}return e})(),$=(()=>{class e extends Kt{static \u0275fac=(()=>{let t;return function(n){return(t||(t=A(e)))(n||e)}})();static \u0275dir=u({type:e,selectors:[["","matListItemIcon",""]],hostAttrs:[1,"mat-mdc-list-item-icon"],features:[T]})}return e})(),me=new B("MAT_LIST_CONFIG"),G=(()=>{class e{_isNonInteractive=!0;get disableRipple(){return this._disableRipple}set disableRipple(t){this._disableRipple=I(t)}_disableRipple=!1;get disabled(){return this._disabled()}set disabled(t){this._disabled.set(I(t))}_disabled=j(!1);_defaultOptions=p(me,{optional:!0});static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,hostVars:1,hostBindings:function(i,n){i&2&&z("aria-disabled",n.disabled)},inputs:{disableRipple:"disableRipple",disabled:"disabled"}})}return e})(),de=(()=>{class e{_elementRef=p(D);_ngZone=p(tt);_listBase=p(G,{optional:!0});_platform=p(ut);_hostElement;_isButtonElement;_noopAnimations=ft();_avatars;_icons;set lines(t){this._explicitLines=wt(t,null),this._updateItemLines(!1)}_explicitLines=null;get disableRipple(){return this.disabled||this._disableRipple||this._noopAnimations||!!this._listBase?.disableRipple}set disableRipple(t){this._disableRipple=I(t)}_disableRipple=!1;get disabled(){return this._disabled()||!!this._listBase?.disabled}set disabled(t){this._disabled.set(I(t))}_disabled=j(!1);_subscriptions=new W;_rippleRenderer=null;_hasUnscopedTextContent=!1;rippleConfig;get rippleDisabled(){return this.disableRipple||!!this.rippleConfig.disabled}constructor(){p(vt).load(It);let t=p(St,{optional:!0});this.rippleConfig=t||{},this._hostElement=this._elementRef.nativeElement,this._isButtonElement=this._hostElement.nodeName.toLowerCase()==="button",this._listBase&&!this._listBase._isNonInteractive&&this._initInteractiveListItem(),this._isButtonElement&&!this._hostElement.hasAttribute("type")&&this._hostElement.setAttribute("type","button")}ngAfterViewInit(){this._monitorProjectedLinesAndTitle(),this._updateItemLines(!0)}ngOnDestroy(){this._subscriptions.unsubscribe(),this._rippleRenderer!==null&&this._rippleRenderer._removeTriggerEvents()}_hasIconOrAvatar(){return!!(this._avatars.length||this._icons.length)}_initInteractiveListItem(){this._hostElement.classList.add("mat-mdc-list-item-interactive"),this._rippleRenderer=new Mt(this,this._ngZone,this._hostElement,this._platform,p(J)),this._rippleRenderer.setupTriggerEvents(this._hostElement)}_monitorProjectedLinesAndTitle(){this._ngZone.runOutsideAngular(()=>{this._subscriptions.add(Z(this._lines.changes,this._titles.changes).subscribe(()=>this._updateItemLines(!1)))})}_updateItemLines(t){if(!this._lines||!this._titles||!this._unscopedContent)return;t&&this._checkDomForUnscopedTextContent();let i=this._explicitLines??this._inferLinesFromContent(),n=this._unscopedContent.nativeElement;if(this._hostElement.classList.toggle("mat-mdc-list-item-single-line",i<=1),this._hostElement.classList.toggle("mdc-list-item--with-one-line",i<=1),this._hostElement.classList.toggle("mdc-list-item--with-two-lines",i===2),this._hostElement.classList.toggle("mdc-list-item--with-three-lines",i===3),this._hasUnscopedTextContent){let r=this._titles.length===0&&i===1;n.classList.toggle("mdc-list-item__primary-text",r),n.classList.toggle("mdc-list-item__secondary-text",!r)}else n.classList.remove("mdc-list-item__primary-text"),n.classList.remove("mdc-list-item__secondary-text")}_inferLinesFromContent(){let t=this._titles.length+this._lines.length;return this._hasUnscopedTextContent&&(t+=1),t}_checkDomForUnscopedTextContent(){this._hasUnscopedTextContent=Array.from(this._unscopedContent.nativeElement.childNodes).filter(t=>t.nodeType!==t.COMMENT_NODE).some(t=>!!(t.textContent&&t.textContent.trim()))}static \u0275fac=function(i){return new(i||e)};static \u0275dir=u({type:e,contentQueries:function(i,n,r){if(i&1&&Q(r,re,4)(r,$,4),i&2){let h;v(h=k())&&(n._avatars=h),v(h=k())&&(n._icons=h)}},hostVars:4,hostBindings:function(i,n){i&2&&(z("aria-disabled",n.disabled)("disabled",n._isButtonElement&&n.disabled||null),S("mdc-list-item--disabled",n.disabled))},inputs:{lines:"lines",disableRipple:"disableRipple",disabled:"disabled"}})}return e})();var Wt=(()=>{class e extends G{static \u0275fac=(()=>{let t;return function(n){return(t||(t=A(e)))(n||e)}})();static \u0275cmp=L({type:e,selectors:[["mat-list"]],hostAttrs:[1,"mat-mdc-list","mat-mdc-list-base","mdc-list"],exportAs:["matList"],features:[it([{provide:G,useExisting:e}]),T],ngContentSelectors:te,decls:1,vars:0,template:function(i,n){i&1&&(V(),x(0))},styles:[ee],encapsulation:2,changeDetection:0})}return e})(),Zt=(()=>{class e extends de{_lines;_titles;_meta;_unscopedContent;_itemText;get activated(){return this._activated}set activated(t){this._activated=I(t)}_activated=!1;_getAriaCurrent(){return this._hostElement.nodeName==="A"&&this._activated?"page":null}_hasBothLeadingAndTrailing(){return this._meta.length!==0&&(this._avatars.length!==0||this._icons.length!==0)}static \u0275fac=(()=>{let t;return function(n){return(t||(t=A(e)))(n||e)}})();static \u0275cmp=L({type:e,selectors:[["mat-list-item"],["a","mat-list-item",""],["button","mat-list-item",""]],contentQueries:function(i,n,r){if(i&1&&Q(r,se,5)(r,U,5)(r,le,5),i&2){let h;v(h=k())&&(n._lines=h),v(h=k())&&(n._titles=h),v(h=k())&&(n._meta=h)}},viewQuery:function(i,n){if(i&1&&et(ie,5)(ne,5),i&2){let r;v(r=k())&&(n._unscopedContent=r.first),v(r=k())&&(n._itemText=r.first)}},hostAttrs:[1,"mat-mdc-list-item","mdc-list-item"],hostVars:13,hostBindings:function(i,n){i&2&&(z("aria-current",n._getAriaCurrent()),S("mdc-list-item--activated",n.activated)("mdc-list-item--with-leading-avatar",n._avatars.length!==0)("mdc-list-item--with-leading-icon",n._icons.length!==0)("mdc-list-item--with-trailing-meta",n._meta.length!==0)("mat-mdc-list-item-both-leading-and-trailing",n._hasBothLeadingAndTrailing())("_mat-animation-noopable",n._noopAnimations))},inputs:{activated:"activated"},exportAs:["matListItem"],features:[T],ngContentSelectors:oe,decls:10,vars:0,consts:[["unscopedContent",""],[1,"mdc-list-item__content"],[1,"mat-mdc-list-item-unscoped-content",3,"cdkObserveContent"],[1,"mat-focus-indicator"]],template:function(i,n){i&1&&(V(ae),x(0),a(1,"span",1),x(2,1),x(3,2),a(4,"span",2,0),b("cdkObserveContent",function(){return n._updateItemLines(!0)}),x(6,3),o()(),x(7,4),x(8,5),f(9,"div",3))},dependencies:[yt],encapsulation:2,changeDetection:0})}return e})();var Yt=(()=>{class e{http;config;constructor(t,i){this.http=t,this.config=i}get base(){return`${this.config.getApiUrl()}/attribute-mappings`}getAll(t){let i=new ct;return t&&(i=i.set("topic",t)),this.http.get(this.base,{params:i})}create(t){return this.http.post(this.base,t)}update(t,i){return this.http.put(`${this.base}/${t}`,i)}delete(t){return this.http.delete(`${this.base}/${t}`)}static \u0275fac=function(i){return new(i||e)(N(st),N(jt))};static \u0275prov=Y({token:e,factory:e.\u0275fac,providedIn:"root"})}return e})();function pe(e,s){if(e&1){let t=P();a(0,"mat-list-item",18),b("click",function(){let n=w(t).$implicit,r=_();return y(r.selectTopic(n))}),a(1,"mat-icon",19),c(2,"data_object"),o(),a(3,"span",20),c(4),o()()}if(e&2){let t=s.$implicit,i=_();S("selected-topic",t===i.selectedTopic),l(),m("ngClass","topic-icon-"+t.replace("-","_")),l(3),g(t)}}function _e(e,s){if(e&1&&(a(0,"span",21),c(1),o()),e&2){let t=s.$implicit;l(),g(t)}}function ge(e,s){if(e&1&&(a(0,"mat-option",36),c(1),o()),e&2){let t=s.$implicit;m("value",t),l(),g(t)}}function be(e,s){if(e&1&&(a(0,"mat-option",36),c(1),o()),e&2){let t=s.$implicit;m("value",t),l(),g(t)}}function ue(e,s){if(e&1&&(a(0,"mat-option",36),c(1),o()),e&2){let t=s.$implicit;m("value",t),l(),g(t)}}function fe(e,s){if(e&1){let t=P();a(0,"div",22)(1,"div",23),c(2),o(),a(3,"form",24)(4,"mat-form-field",25)(5,"mat-label"),c(6,"Source Field"),o(),a(7,"mat-select",26),d(8,ge,2,2,"mat-option",27),o()(),a(9,"mat-form-field",25)(10,"mat-label"),c(11,"FAME Series Name"),o(),f(12,"input",28),o(),a(13,"mat-form-field",25)(14,"mat-label"),c(15,"Data Type"),o(),a(16,"mat-select",29),d(17,be,2,2,"mat-option",27),o()(),a(18,"mat-form-field",25)(19,"mat-label"),c(20,"Aggregation"),o(),a(21,"mat-select",30),d(22,ue,2,2,"mat-option",27),o()(),a(23,"mat-form-field",25)(24,"mat-label"),c(25,"Description"),o(),f(26,"input",31),o(),a(27,"mat-slide-toggle",32),b("change",function(n){let r;w(t);let h=_();return y((r=h.form.get("active"))==null?null:r.setValue(n.checked?1:0))}),c(28," Active "),o(),a(29,"div",33)(30,"button",34),b("click",function(){w(t);let n=_();return y(n.cancelForm())}),c(31,"Cancel"),o(),a(32,"button",35),b("click",function(){w(t);let n=_();return y(n.save())}),c(33),o()()()()}if(e&2){let t,i=_();l(2),g(i.editingId?"Edit Mapping":"New Mapping"),l(),m("formGroup",i.form),l(5),m("ngForOf",i.availableFields),l(9),m("ngForOf",i.dataTypes),l(5),m("ngForOf",i.aggregations),l(5),m("checked",((t=i.form.get("active"))==null?null:t.value)===1),l(5),m("disabled",i.form.invalid),l(),R(" ",i.editingId?"Update":"Create"," ")}}function xe(e,s){e&1&&(a(0,"div",37),f(1,"mat-spinner",38),o())}function ve(e,s){if(e&1&&(a(0,"div",39),c(1),o()),e&2){let t=_();l(),R(" No mappings defined for ",t.selectedTopic,'. Click "Add Mapping" to create one. ')}}function ke(e,s){e&1&&(a(0,"th",51),c(1,"Source Field"),o())}function we(e,s){if(e&1&&(a(0,"td",52),c(1),o()),e&2){let t=s.$implicit;l(),g(t.sourceField)}}function ye(e,s){e&1&&(a(0,"th",51),c(1,"FAME Series"),o())}function Ce(e,s){if(e&1&&(a(0,"td",52),c(1),o()),e&2){let t=s.$implicit;l(),g(t.fameSeriesName)}}function Me(e,s){e&1&&(a(0,"th",51),c(1,"Type"),o())}function Se(e,s){if(e&1&&(a(0,"td",52),c(1),o()),e&2){let t=s.$implicit;l(),g(t.dataType)}}function Ie(e,s){e&1&&(a(0,"th",51),c(1,"Aggregation"),o())}function Ae(e,s){if(e&1&&(a(0,"td",52),c(1),o()),e&2){let t=s.$implicit;l(),g(t.aggregation)}}function Le(e,s){e&1&&(a(0,"th",51),c(1,"Active"),o())}function Te(e,s){if(e&1&&(a(0,"td",52)(1,"span",53),c(2),o()()),e&2){let t=s.$implicit;l(),S("badge-active",t.active===1)("badge-inactive",t.active!==1),l(),R(" ",t.active===1?"Yes":"No"," ")}}function Oe(e,s){e&1&&(a(0,"th",51),c(1,"Actions"),o())}function Ee(e,s){if(e&1){let t=P();a(0,"td",52)(1,"button",54),b("click",function(){let n=w(t).$implicit,r=_(2);return y(r.openEditForm(n))}),a(2,"mat-icon"),c(3,"edit"),o()(),a(4,"button",55),b("click",function(){let n=w(t).$implicit,r=_(2);return y(r.delete(n))}),a(5,"mat-icon"),c(6,"delete"),o()()()}}function De(e,s){e&1&&f(0,"tr",56)}function Fe(e,s){e&1&&f(0,"tr",57)}function ze(e,s){if(e&1&&(a(0,"table",40),C(1,41),d(2,ke,2,0,"th",42)(3,we,2,1,"td",43),M(),C(4,44),d(5,ye,2,0,"th",42)(6,Ce,2,1,"td",43),M(),C(7,45),d(8,Me,2,0,"th",42)(9,Se,2,1,"td",43),M(),C(10,46),d(11,Ie,2,0,"th",42)(12,Ae,2,1,"td",43),M(),C(13,47),d(14,Le,2,0,"th",42)(15,Te,3,5,"td",43),M(),C(16,48),d(17,Oe,2,0,"th",42)(18,Ee,7,0,"td",43),M(),d(19,De,1,0,"tr",49)(20,Fe,1,0,"tr",50),o()),e&2){let t=_();m("dataSource",t.mappings),l(19),m("matHeaderRowDef",t.displayedColumns),l(),m("matRowDefColumns",t.displayedColumns)}}var Jt={"market-data":["vwap","daily_high","daily_low","daily_volume","bid_volume","ask_volume","latency_us","price_change_pct","tick_id","liquidity_provider","quote_source","is_indicative","market_depth"],"pre-trade":["trader_id","order_id","order_type","side","counterparty","order_status","time_in_force","algorithm","settlement_type","limit_price","risk_check_passed","requested_volume","quote_ttl_ms","client_order_ref","settlement_date"],"post-trade":["trade_id","trader_id","side","counterparty","executed_price","executed_volume","execution_time_ms","slippage_bps","pnl_usd","fees_usd","trade_status","settlement_type","settlement_date","clearing_house","confirmation_id","order_id"]},q=["market-data","pre-trade","post-trade"],Pe=["DOUBLE","INTEGER","STRING","BOOLEAN"],Re=["LAST","FIRST","SUM","AVG","MIN","MAX","COUNT"],Ri=(()=>{class e{mappingService;fb;snackBar;topics=q;selectedTopic=q[0];availableFields=Jt[q[0]];dataTypes=Pe;aggregations=Re;mappings=[];displayedColumns=["sourceField","fameSeriesName","dataType","aggregation","active","actions"];loading=!1;showForm=!1;editingId=null;form;constructor(t,i,n){this.mappingService=t,this.fb=i,this.snackBar=n,this.form=this.fb.group({sourceField:["",H.required],fameSeriesName:["",H.required],dataType:["DOUBLE"],aggregation:["LAST"],active:[1],description:[""]})}ngOnInit(){this.loadMappings()}selectTopic(t){this.selectedTopic=t,this.availableFields=Jt[t]||[],this.showForm=!1,this.editingId=null,this.loadMappings()}loadMappings(){this.loading=!0,this.mappingService.getAll(this.selectedTopic).pipe(E(()=>O([]))).subscribe(t=>{this.mappings=t,this.loading=!1})}openAddForm(){this.editingId=null,this.form.reset({dataType:"DOUBLE",aggregation:"LAST",active:1}),this.showForm=!0}openEditForm(t){this.editingId=t.id??null,this.form.patchValue(t),this.showForm=!0}cancelForm(){this.showForm=!1,this.editingId=null}save(){if(this.form.invalid)return;let t=K(X({},this.form.value),{topicName:this.selectedTopic});(this.editingId?this.mappingService.update(this.editingId,t):this.mappingService.create(t)).pipe(E(n=>(this.snackBar.open("Save failed: "+(n.message||"Unknown error"),"Close",{duration:3e3}),O(null)))).subscribe(n=>{n&&(this.snackBar.open("Saved successfully","Close",{duration:2e3}),this.showForm=!1,this.editingId=null,this.loadMappings())})}delete(t){t.id&&confirm(`Delete mapping "${t.sourceField} \u2192 ${t.fameSeriesName}"?`)&&this.mappingService.delete(t.id).pipe(E(i=>(this.snackBar.open("Delete failed","Close",{duration:3e3}),O(null)))).subscribe(()=>{this.snackBar.open("Deleted","Close",{duration:2e3}),this.loadMappings()})}static \u0275fac=function(i){return new(i||e)(F(Yt),F(_t),F(qt))};static \u0275cmp=L({type:e,selectors:[["app-attribute-mapping"]],decls:27,vars:6,consts:[[1,"am-page"],[1,"am-header"],[1,"am-header-icon"],[1,"spacer"],["mat-raised-button","","color","primary",3,"click"],[1,"am-layout"],[1,"am-left-panel"],[1,"panel-title"],["class","topic-item",3,"selected-topic","click",4,"ngFor","ngForOf"],[1,"panel-title","field-title"],[1,"field-list"],["class","field-chip",4,"ngFor","ngForOf"],[1,"am-right-panel"],["class","am-form-card",4,"ngIf"],[1,"table-card"],["class","loading-row",4,"ngIf"],["class","empty-state",4,"ngIf"],["mat-table","","class","am-table",3,"dataSource",4,"ngIf"],[1,"topic-item",3,"click"],["matListItemIcon","",3,"ngClass"],["matListItemTitle",""],[1,"field-chip"],[1,"am-form-card"],[1,"form-title"],[1,"am-form",3,"formGroup"],["appearance","outline"],["formControlName","sourceField"],[3,"value",4,"ngFor","ngForOf"],["matInput","","formControlName","fameSeriesName","placeholder","e.g. FX.EURUSD.VWAP"],["formControlName","dataType"],["formControlName","aggregation"],["matInput","","formControlName","description"],["formControlName","active",3,"change","checked"],[1,"form-actions"],["mat-button","",3,"click"],["mat-raised-button","","color","primary",3,"click","disabled"],[3,"value"],[1,"loading-row"],["diameter","32"],[1,"empty-state"],["mat-table","",1,"am-table",3,"dataSource"],["matColumnDef","sourceField"],["mat-header-cell","",4,"matHeaderCellDef"],["mat-cell","",4,"matCellDef"],["matColumnDef","fameSeriesName"],["matColumnDef","dataType"],["matColumnDef","aggregation"],["matColumnDef","active"],["matColumnDef","actions"],["mat-header-row","",4,"matHeaderRowDef"],["mat-row","",4,"matRowDef","matRowDefColumns"],["mat-header-cell",""],["mat-cell",""],[1,"status-badge"],["mat-icon-button","","color","primary","matTooltip","Edit",3,"click"],["mat-icon-button","","color","warn","matTooltip","Delete",3,"click"],["mat-header-row",""],["mat-row",""]],template:function(i,n){i&1&&(a(0,"div",0)(1,"div",1)(2,"mat-icon",2),c(3,"swap_horiz"),o(),a(4,"h2"),c(5,"Attribute Mappings"),o(),f(6,"span",3),a(7,"button",4),b("click",function(){return n.openAddForm()}),a(8,"mat-icon"),c(9,"add"),o(),c(10," Add Mapping "),o()(),a(11,"div",5)(12,"div",6)(13,"div",7),c(14,"Topics"),o(),a(15,"mat-list"),d(16,pe,5,4,"mat-list-item",8),o(),a(17,"div",9),c(18,"Known Fields"),o(),a(19,"div",10),d(20,_e,2,1,"span",11),o()(),a(21,"div",12),d(22,fe,34,8,"div",13),a(23,"div",14),d(24,xe,2,0,"div",15)(25,ve,2,1,"div",16)(26,ze,21,3,"table",17),o()()()()),i&2&&(l(16),m("ngForOf",n.topics),l(4),m("ngForOf",n.availableFields),l(2),m("ngIf",n.showForm),l(2),m("ngIf",n.loading),l(),m("ngIf",!n.loading&&n.mappings.length===0),l(),m("ngIf",!n.loading&&n.mappings.length>0))},dependencies:[kt,Lt,Wt,at,Zt,$,nt,U,ot,gt,dt,lt,rt,mt,bt,pt,ht,Qt,Vt,Ut,Gt,Ht,$t,xt,Tt,Dt,Et,Ft,Ot,zt,At,Ct,Pt,Bt,Rt,Nt],styles:[".am-page[_ngcontent-%COMP%]{padding:24px;background:#f5f5f5;min-height:100vh}.am-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;margin-bottom:24px}.am-header-icon[_ngcontent-%COMP%]{color:#1976d2;font-size:28px}.am-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;font-size:22px;font-weight:600;color:#333}.spacer[_ngcontent-%COMP%]{flex:1}.am-layout[_ngcontent-%COMP%]{display:flex;gap:16px}.am-left-panel[_ngcontent-%COMP%]{width:240px;min-width:200px;background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:12px 0}.panel-title[_ngcontent-%COMP%]{font-size:11px;font-weight:600;text-transform:uppercase;color:#888;padding:8px 16px 4px;letter-spacing:.5px}.field-title[_ngcontent-%COMP%]{margin-top:12px;border-top:1px solid #e0e0e0}.topic-item[_ngcontent-%COMP%]{cursor:pointer}.topic-item[_ngcontent-%COMP%]:hover{background:#f5f5f5}.topic-item.selected-topic[_ngcontent-%COMP%]{background:#e3f2fd;color:#1976d2}.field-list[_ngcontent-%COMP%]{padding:8px 12px;display:flex;flex-wrap:wrap;gap:6px}.field-chip[_ngcontent-%COMP%]{background:#f0f4ff;border:1px solid #c5d8f0;border-radius:12px;padding:2px 8px;font-size:11px;color:#1976d2}.am-right-panel[_ngcontent-%COMP%]{flex:1;display:flex;flex-direction:column;gap:16px}.am-form-card[_ngcontent-%COMP%]{background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:20px}.form-title[_ngcontent-%COMP%]{font-size:15px;font-weight:600;color:#333;margin-bottom:16px}.am-form[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:12px}.am-form[_ngcontent-%COMP%]   mat-form-field[_ngcontent-%COMP%]{width:100%}.am-form[_ngcontent-%COMP%]   mat-slide-toggle[_ngcontent-%COMP%]{align-self:center}.form-actions[_ngcontent-%COMP%]{grid-column:1/-1;display:flex;gap:8px;justify-content:flex-end}.table-card[_ngcontent-%COMP%]{background:#fff;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden}.am-table[_ngcontent-%COMP%]{width:100%}.am-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{background:#f5f5f5;font-weight:600;color:#555}.loading-row[_ngcontent-%COMP%], .empty-state[_ngcontent-%COMP%]{padding:40px;text-align:center;color:#888}.status-badge[_ngcontent-%COMP%]{padding:2px 10px;border-radius:12px;font-size:12px;font-weight:500}.status-badge.badge-active[_ngcontent-%COMP%]{background:#e8f5e9;color:#388e3c}.status-badge.badge-inactive[_ngcontent-%COMP%]{background:#fafafa;color:#999;border:1px solid #e0e0e0}"]})}return e})();export{Ri as AttributeMappingComponent};
