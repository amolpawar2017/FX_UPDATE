import{a as it,b as at,c as ot}from"./chunk-5N3GGIRV.js";import{b as be}from"./chunk-EA57GCJO.js";import{a as qe}from"./chunk-BXCPJROL.js";import"./chunk-QIGFEJDJ.js";import{a as nt}from"./chunk-BCCDUILC.js";import{a as Je,b as et}from"./chunk-PX3UZRRK.js";import{a as Qe,b as Xe}from"./chunk-6H5RGPXM.js";import{a as Ve}from"./chunk-HDFBS7AW.js";import{a as Ye}from"./chunk-3D3FRWOZ.js";import{a as tt}from"./chunk-U4YX2DQY.js";import{d as je,g as He,k as We,m as Ze,n as Ke}from"./chunk-PNTILEUX.js";import{a as fe,b as ke,c as ve,d as f,f as ye,g as Ce,i as Me,j as Se,k as Pe,l as Ie,m as we,n as Ee,o as Oe,p as Ae,q as Te,r as Ue}from"./chunk-5AU5NM3W.js";import{a as Re}from"./chunk-BHI5CEHR.js";import"./chunk-X6W5R2HS.js";import{G as ze,f as Fe,i as De,k as Le,na as Ge,pa as Ne,qa as $e,sa as Be}from"./chunk-VJULX6IE.js";import"./chunk-254FYNHO.js";import{d as _e,e as ge,f as xe}from"./chunk-FYW6F2XK.js";import{$a as r,$b as oe,Bc as me,Ca as ne,Db as z,Fa as ie,Hc as pe,K as w,Kb as l,Lb as a,Mb as i,Mc as he,Nb as g,Pc as O,Qc as ue,Rb as R,Sb as G,Ub as C,Vb as ae,Y as S,Yb as h,_b as d,a as F,ac as ce,b as Q,ba as Y,cc as re,dc as N,ec as $,fa as Z,ha as E,ib as A,ic as D,kc as y,l as X,lc as se,ma as u,mc as o,na as _,nc as b,oa as K,ob as V,oc as v,pa as J,pc as de,rc as B,s as I,sc as q,tc as j,ua as L,ub as x,va as ee,vc as le,ya as te}from"./chunk-OYT7HEGD.js";var st=["input"],dt=["label"],lt=["*"],H={color:"accent",clickAction:"check-indeterminate",disabledInteractive:!1},mt=new Z("mat-checkbox-default-options",{providedIn:"root",factory:()=>H}),k=(function(c){return c[c.Init=0]="Init",c[c.Checked=1]="Checked",c[c.Unchecked=2]="Unchecked",c[c.Indeterminate=3]="Indeterminate",c})(k||{}),W=class{source;checked},ct=(()=>{class c{_elementRef=E(ie);_changeDetectorRef=E(he);_ngZone=E(ee);_animationsDisabled=Fe();_options=E(mt,{optional:!0});focus(){this._inputElement.nativeElement.focus()}_createChangeEvent(e){let n=new W;return n.source=this,n.checked=e,n}_getAnimationTargetElement(){return this._inputElement?.nativeElement}_animationClasses={uncheckedToChecked:"mdc-checkbox--anim-unchecked-checked",uncheckedToIndeterminate:"mdc-checkbox--anim-unchecked-indeterminate",checkedToUnchecked:"mdc-checkbox--anim-checked-unchecked",checkedToIndeterminate:"mdc-checkbox--anim-checked-indeterminate",indeterminateToChecked:"mdc-checkbox--anim-indeterminate-checked",indeterminateToUnchecked:"mdc-checkbox--anim-indeterminate-unchecked"};ariaLabel="";ariaLabelledby=null;ariaDescribedby;ariaExpanded;ariaControls;ariaOwns;_uniqueId;id;get inputId(){return`${this.id||this._uniqueId}-input`}required=!1;labelPosition="after";name=null;change=new L;indeterminateChange=new L;value;disableRipple=!1;_inputElement;_labelElement;tabIndex;color;disabledInteractive;_onTouched=()=>{};_currentAnimationClass="";_currentCheckState=k.Init;_controlValueAccessorChangeFn=()=>{};_validatorChangeFn=()=>{};constructor(){E(De).load(Ne);let e=E(new pe("tabindex"),{optional:!0});this._options=this._options||H,this.color=this._options.color||H.color,this.tabIndex=e==null?0:parseInt(e)||0,this.id=this._uniqueId=E(ze).getId("mat-mdc-checkbox-"),this.disabledInteractive=this._options?.disabledInteractive??!1}ngOnChanges(e){e.required&&this._validatorChangeFn()}ngAfterViewInit(){this._syncIndeterminate(this.indeterminate)}get checked(){return this._checked}set checked(e){e!=this.checked&&(this._checked=e,this._changeDetectorRef.markForCheck())}_checked=!1;get disabled(){return this._disabled}set disabled(e){e!==this.disabled&&(this._disabled=e,this._changeDetectorRef.markForCheck())}_disabled=!1;get indeterminate(){return this._indeterminate()}set indeterminate(e){let n=e!=this._indeterminate();this._indeterminate.set(e),n&&(e?this._transitionCheckState(k.Indeterminate):this._transitionCheckState(this.checked?k.Checked:k.Unchecked),this.indeterminateChange.emit(e)),this._syncIndeterminate(e)}_indeterminate=te(!1);_isRippleDisabled(){return this.disableRipple||this.disabled}_onLabelTextChange(){this._changeDetectorRef.detectChanges()}writeValue(e){this.checked=!!e}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e}validate(e){return this.required&&e.value!==!0?{required:!0}:null}registerOnValidatorChange(e){this._validatorChangeFn=e}_transitionCheckState(e){let n=this._currentCheckState,t=this._getAnimationTargetElement();if(!(n===e||!t)&&(this._currentAnimationClass&&t.classList.remove(this._currentAnimationClass),this._currentAnimationClass=this._getAnimationClassForCheckStateTransition(n,e),this._currentCheckState=e,this._currentAnimationClass.length>0)){t.classList.add(this._currentAnimationClass);let s=this._currentAnimationClass;this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{t.classList.remove(s)},1e3)})}}_emitChangeEvent(){this._controlValueAccessorChangeFn(this.checked),this.change.emit(this._createChangeEvent(this.checked)),this._inputElement&&(this._inputElement.nativeElement.checked=this.checked)}toggle(){this.checked=!this.checked,this._controlValueAccessorChangeFn(this.checked)}_handleInputClick(){let e=this._options?.clickAction;!this.disabled&&e!=="noop"?(this.indeterminate&&e!=="check"&&Promise.resolve().then(()=>{this._indeterminate.set(!1),this.indeterminateChange.emit(!1)}),this._checked=!this._checked,this._transitionCheckState(this._checked?k.Checked:k.Unchecked),this._emitChangeEvent()):(this.disabled&&this.disabledInteractive||!this.disabled&&e==="noop")&&(this._inputElement.nativeElement.checked=this.checked,this._inputElement.nativeElement.indeterminate=this.indeterminate)}_onInteractionEvent(e){e.stopPropagation()}_onBlur(){Promise.resolve().then(()=>{this._onTouched(),this._changeDetectorRef.markForCheck()})}_getAnimationClassForCheckStateTransition(e,n){if(this._animationsDisabled)return"";switch(e){case k.Init:if(n===k.Checked)return this._animationClasses.uncheckedToChecked;if(n==k.Indeterminate)return this._checked?this._animationClasses.checkedToIndeterminate:this._animationClasses.uncheckedToIndeterminate;break;case k.Unchecked:return n===k.Checked?this._animationClasses.uncheckedToChecked:this._animationClasses.uncheckedToIndeterminate;case k.Checked:return n===k.Unchecked?this._animationClasses.checkedToUnchecked:this._animationClasses.checkedToIndeterminate;case k.Indeterminate:return n===k.Checked?this._animationClasses.indeterminateToChecked:this._animationClasses.indeterminateToUnchecked}return""}_syncIndeterminate(e){let n=this._inputElement;n&&(n.nativeElement.indeterminate=e)}_onInputClick(){this._handleInputClick()}_onTouchTargetClick(){this._handleInputClick(),this.disabled||this._inputElement.nativeElement.focus()}_preventBubblingFromLabel(e){e.target&&this._labelElement.nativeElement.contains(e.target)&&e.stopPropagation()}static \u0275fac=function(n){return new(n||c)};static \u0275cmp=V({type:c,selectors:[["mat-checkbox"]],viewQuery:function(n,t){if(n&1&&re(st,5)(dt,5),n&2){let s;N(s=$())&&(t._inputElement=s.first),N(s=$())&&(t._labelElement=s.first)}},hostAttrs:[1,"mat-mdc-checkbox"],hostVars:16,hostBindings:function(n,t){n&2&&(ae("id",t.id),z("tabindex",null)("aria-label",null)("aria-labelledby",null),se(t.color?"mat-"+t.color:"mat-accent"),y("_mat-animation-noopable",t._animationsDisabled)("mdc-checkbox--disabled",t.disabled)("mat-mdc-checkbox-disabled",t.disabled)("mat-mdc-checkbox-checked",t.checked)("mat-mdc-checkbox-disabled-interactive",t.disabledInteractive))},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],ariaExpanded:[2,"aria-expanded","ariaExpanded",O],ariaControls:[0,"aria-controls","ariaControls"],ariaOwns:[0,"aria-owns","ariaOwns"],id:"id",required:[2,"required","required",O],labelPosition:"labelPosition",name:"name",value:"value",disableRipple:[2,"disableRipple","disableRipple",O],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?void 0:ue(e)],color:"color",disabledInteractive:[2,"disabledInteractive","disabledInteractive",O],checked:[2,"checked","checked",O],disabled:[2,"disabled","disabled",O],indeterminate:[2,"indeterminate","indeterminate",O]},outputs:{change:"change",indeterminateChange:"indeterminateChange"},exportAs:["matCheckbox"],features:[le([{provide:fe,useExisting:Y(()=>c),multi:!0},{provide:ve,useExisting:c,multi:!0}]),ne],ngContentSelectors:lt,decls:15,vars:23,consts:[["checkbox",""],["input",""],["label",""],["mat-internal-form-field","",3,"click","labelPosition"],[1,"mdc-checkbox"],["aria-hidden","true",1,"mat-mdc-checkbox-touch-target",3,"click"],["type","checkbox",1,"mdc-checkbox__native-control",3,"blur","click","change","checked","indeterminate","disabled","id","required","tabIndex"],["aria-hidden","true",1,"mdc-checkbox__ripple"],["aria-hidden","true",1,"mdc-checkbox__background"],["focusable","false","viewBox","0 0 24 24",1,"mdc-checkbox__checkmark"],["fill","none","d","M1.73,12.91 8.1,19.28 22.79,4.59",1,"mdc-checkbox__checkmark-path"],[1,"mdc-checkbox__mixedmark"],["mat-ripple","","aria-hidden","true",1,"mat-mdc-checkbox-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-label",3,"for"]],template:function(n,t){if(n&1&&(oe(),a(0,"div",3),h("click",function(m){return t._preventBubblingFromLabel(m)}),a(1,"div",4,0)(3,"div",5),h("click",function(){return t._onTouchTargetClick()}),i(),a(4,"input",6,1),h("blur",function(){return t._onBlur()})("click",function(){return t._onInputClick()})("change",function(m){return t._onInteractionEvent(m)}),i(),g(6,"div",7),a(7,"div",8),K(),a(8,"svg",9),g(9,"path",10),i(),J(),g(10,"div",11),i(),g(11,"div",12),i(),a(12,"label",13,2),ce(14),i()()),n&2){let s=D(2);l("labelPosition",t.labelPosition),r(4),y("mdc-checkbox--selected",t.checked),l("checked",t.checked)("indeterminate",t.indeterminate)("disabled",t.disabled&&!t.disabledInteractive)("id",t.inputId)("required",t.required)("tabIndex",t.disabled&&!t.disabledInteractive?-1:t.tabIndex),z("aria-label",t.ariaLabel||null)("aria-labelledby",t.ariaLabelledby)("aria-describedby",t.ariaDescribedby)("aria-checked",t.indeterminate?"mixed":null)("aria-controls",t.ariaControls)("aria-disabled",t.disabled&&t.disabledInteractive?!0:null)("aria-expanded",t.ariaExpanded)("aria-owns",t.ariaOwns)("name",t.name)("value",t.value),r(7),l("matRippleTrigger",s)("matRippleDisabled",t.disableRipple||t.disabled)("matRippleCentered",!0),r(),l("for",t.inputId)}},dependencies:[Ge,Je],styles:[`.mdc-checkbox {
  display: inline-block;
  position: relative;
  flex: 0 0 18px;
  box-sizing: content-box;
  width: 18px;
  height: 18px;
  line-height: 0;
  white-space: nowrap;
  cursor: pointer;
  vertical-align: bottom;
  padding: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  margin: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}
.mdc-checkbox:hover > .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:hover > .mat-mdc-checkbox-ripple > .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control {
  position: absolute;
  margin: 0;
  padding: 0;
  opacity: 0;
  cursor: inherit;
  z-index: 1;
  width: var(--mat-checkbox-state-layer-size, 40px);
  height: var(--mat-checkbox-state-layer-size, 40px);
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  right: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}

.mdc-checkbox--disabled {
  cursor: default;
  pointer-events: none;
}

.mdc-checkbox__background {
  display: inline-flex;
  position: absolute;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  width: 18px;
  height: 18px;
  border: 2px solid currentColor;
  border-radius: 2px;
  background-color: transparent;
  pointer-events: none;
  will-change: background-color, border-color;
  transition: background-color 90ms cubic-bezier(0.4, 0, 0.6, 1), border-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
  -webkit-print-color-adjust: exact;
  color-adjust: exact;
  border-color: var(--mat-checkbox-unselected-icon-color, var(--mat-sys-on-surface-variant));
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
}

.mdc-checkbox__native-control:enabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:enabled:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}
@media (forced-colors: active) {
  .mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
  .mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-hover-icon-color, var(--mat-sys-on-surface));
  background-color: transparent;
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox__native-control:focus:focus:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-focus-icon-color, var(--mat-sys-on-surface));
}

.mdc-checkbox__native-control:focus:focus:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
    border-color: GrayText;
  }
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}

.mdc-checkbox__checkmark {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  opacity: 0;
  transition: opacity 180ms cubic-bezier(0.4, 0, 0.6, 1);
  color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__checkmark {
    color: CanvasText;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
  color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
    color: GrayText;
  }
}

.mdc-checkbox__checkmark-path {
  transition: stroke-dashoffset 180ms cubic-bezier(0.4, 0, 0.6, 1);
  stroke: currentColor;
  stroke-width: 3.12px;
  stroke-dashoffset: 29.7833385;
  stroke-dasharray: 29.7833385;
}

.mdc-checkbox__mixedmark {
  width: 100%;
  height: 0;
  transform: scaleX(0) rotate(0deg);
  border-width: 1px;
  border-style: solid;
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
  border-color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__mixedmark {
    margin: 0 1px;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
  border-color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
    border-color: GrayText;
  }
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__background,
.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__background,
.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__background,
.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__background {
  animation-duration: 180ms;
  animation-timing-function: linear;
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-unchecked-checked-checkmark-path 180ms linear;
  transition: none;
}

.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-unchecked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-checked-unchecked-checkmark-path 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__checkmark {
  animation: mdc-checkbox-checked-indeterminate-checkmark 90ms linear;
  transition: none;
}
.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-checked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__checkmark {
  animation: mdc-checkbox-indeterminate-checked-checkmark 500ms linear;
  transition: none;
}
.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-checked-mixedmark 500ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-unchecked-mixedmark 300ms linear;
  transition: none;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 1), background-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path {
  stroke-dashoffset: 0;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transition: opacity 180ms cubic-bezier(0, 0, 0.2, 1), transform 180ms cubic-bezier(0, 0, 0.2, 1);
  opacity: 1;
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(-45deg);
}

.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transform: rotate(45deg);
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
}
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(0deg);
  opacity: 1;
}

@keyframes mdc-checkbox-unchecked-checked-checkmark-path {
  0%, 50% {
    stroke-dashoffset: 29.7833385;
  }
  50% {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
  }
  100% {
    stroke-dashoffset: 0;
  }
}
@keyframes mdc-checkbox-unchecked-indeterminate-mixedmark {
  0%, 68.2% {
    transform: scaleX(0);
  }
  68.2% {
    animation-timing-function: cubic-bezier(0, 0, 0, 1);
  }
  100% {
    transform: scaleX(1);
  }
}
@keyframes mdc-checkbox-checked-unchecked-checkmark-path {
  from {
    animation-timing-function: cubic-bezier(0.4, 0, 1, 1);
    opacity: 1;
    stroke-dashoffset: 0;
  }
  to {
    opacity: 0;
    stroke-dashoffset: -29.7833385;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-checkmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(45deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-checkmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(45deg);
    opacity: 0;
  }
  to {
    transform: rotate(360deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(-45deg);
    opacity: 0;
  }
  to {
    transform: rotate(0deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(315deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-unchecked-mixedmark {
  0% {
    animation-timing-function: linear;
    transform: scaleX(1);
    opacity: 1;
  }
  32.8%, 100% {
    transform: scaleX(0);
    opacity: 0;
  }
}
.mat-mdc-checkbox {
  display: inline-block;
  position: relative;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-touch-target,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__native-control,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__ripple,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-ripple::before,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-checkbox label {
  cursor: pointer;
}
.mat-mdc-checkbox .mat-internal-form-field {
  color: var(--mat-checkbox-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-checkbox-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-checkbox-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-checkbox-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-checkbox-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-checkbox-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive input {
  cursor: default;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
  cursor: default;
  color: var(--mat-checkbox-disabled-label-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
    color: GrayText;
  }
}
.mat-mdc-checkbox label:empty {
  display: none;
}
.mat-mdc-checkbox .mdc-checkbox__ripple {
  opacity: 0;
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple,
.mdc-checkbox__ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-checkbox .mat-mdc-checkbox-ripple:not(:empty),
.mdc-checkbox__ripple:not(:empty) {
  transform: translateZ(0);
}

.mat-mdc-checkbox-ripple .mat-ripple-element {
  opacity: 0.1;
}

.mat-mdc-checkbox-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-checkbox-touch-target-size, 48px);
  width: var(--mat-checkbox-touch-target-size, 48px);
  transform: translate(-50%, -50%);
  display: var(--mat-checkbox-touch-target-display, block);
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple::before {
  border-radius: 50%;
}

.mdc-checkbox__native-control:focus-visible ~ .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2,changeDetection:0})}return c})();function pt(c,p){if(c&1&&(a(0,"div",18)(1,"div",19)(2,"span",20),o(3),i(),a(4,"span",21),o(5,"Total"),i()(),a(6,"div",22)(7,"span",20),o(8),i(),a(9,"span",21),o(10,"Active"),i()(),a(11,"div",23)(12,"span",20),o(13),i(),a(14,"span",21),o(15,"Inactive"),i()()()),c&2){let e=d();r(3),b(e.stats.total),r(5),b(e.stats.active),r(5),b(e.stats.inactive)}}function ht(c,p){if(c&1){let e=C();a(0,"div",24),h("click",function(){u(e);let t=d();return _(t.openAuthSettings())}),a(1,"span",25),o(2),i(),o(3),a(4,"span",26),o(5,"settings"),i()()}if(c&2){let e=d();y("ldap-chip",e.isLdapMode),r(2),b(e.isLdapMode?"corporate_fare":"lock"),r(),v(" ",e.isLdapMode?"LDAP Auth":"Local Auth"," ")}}function ut(c,p){c&1&&(a(0,"div",27),g(1,"mat-spinner",28),i())}function _t(c,p){c&1&&(a(0,"div",32),o(1,"No users found."),i())}function gt(c,p){if(c&1){let e=C();a(0,"div",33),h("click",function(){let t=u(e).$implicit,s=d(2);return _(s.selectUser(t))}),a(1,"div",34),o(2),i(),a(3,"div",35)(4,"div",36),o(5),i(),a(6,"div",37),o(7),i()(),a(8,"div",38)(9,"span",39),o(10),i(),g(11,"span",40),i()()}if(c&2){let e=p.$implicit,n=d(2);y("selected",(n.selectedUser==null?null:n.selectedUser.userId)===e.userId),r(),y("inactive-avatar",!e.isActive),r(),b(n.getInitials(e)),r(3),b(e.fullName||e.username),r(2),v("@",e.username),r(2),l("ngClass",n.roleBadgeClass(e.role||"VIEWER")),r(),b(e.role||"VIEWER"),r(),y("dot-active",e.isActive)("dot-inactive",!e.isActive),l("matTooltip",e.isActive?"Active":"Inactive")}}function xt(c,p){if(c&1&&(a(0,"div",29),x(1,_t,2,0,"div",30)(2,gt,12,14,"div",31),i()),c&2){let e=d();r(),l("ngIf",e.filteredUsers.length===0),r(),l("ngForOf",e.filteredUsers)}}function bt(c,p){if(c&1){let e=C();a(0,"div",81),h("click",function(){let t=u(e).$implicit,s=d(2);return _(s.selectedRole=t)}),a(1,"div",82),g(2,"div",83),i(),a(3,"div",84)(4,"div",85)(5,"span",86),o(6),i()(),a(7,"div",87),o(8),i()()()}if(c&2){let e=p.$implicit,n=d(2);y("role-selected",n.selectedRole===e),r(2),y("radio-active",n.selectedRole===e),r(3),l("ngClass",n.roleBadgeClass(e)),r(),b(e),r(2),b(n.roleDescriptions[e])}}function ft(c,p){c&1&&(a(0,"div",88)(1,"span",25),o(2,"info"),i(),o(3," No data sources discovered yet. Data pairs are auto-populated when Kafka messages arrive. "),i())}function kt(c,p){if(c&1&&(a(0,"span",89),o(1),i()),c&2){let e=d(2);r(),v(" ",e.allIndicators.length," indicator(s) ")}}function vt(c,p){c&1&&(a(0,"div",90),g(1,"mat-spinner",91),a(2,"span"),o(3,"Loading indicator permissions\u2026"),i()())}function yt(c,p){if(c&1){let e=C();a(0,"div",94)(1,"span",95),o(2),i(),a(3,"div",96)(4,"mat-checkbox",97),h("change",function(t){let s=u(e).$implicit,m=d(3);return _(m.toggleIndRead(s,t.checked))}),o(5," Read "),i(),a(6,"mat-checkbox",98),h("change",function(t){let s=u(e).$implicit,m=d(3);return _(m.toggleIndExecute(s,t.checked))}),o(7," Execute "),i()()()}if(c&2){let e=p.$implicit,n=d(3);r(2),b(e.name),r(2),l("checked",n.hasIndRead(e))("disabled",n.allIndicatorsGranted),r(2),l("checked",n.hasIndExecute(e))("disabled",n.allIndicatorsGranted||!n.hasIndRead(e))}}function Ct(c,p){if(c&1&&(a(0,"div",92),x(1,yt,8,5,"div",93),i()),c&2){let e=d(2);r(),l("ngForOf",e.allIndicators)}}function Mt(c,p){c&1&&(a(0,"div",99),o(1," No indicators defined yet. "),i())}function St(c,p){if(c&1&&(a(0,"span",89),o(1),i()),c&2){let e=d().$implicit,n=d(3);r(),v(" ",n.getSourcesForType(e).length," source(s) ")}}function Pt(c,p){if(c&1){let e=C();a(0,"div",115)(1,"mat-checkbox",97),h("change",function(t){let s=u(e).$implicit,m=d(2).$implicit,M=d(2).$implicit,P=d(3);return _(P.togglePairGrant(M,m,s,t.checked))}),o(2),i()()}if(c&2){let e=p.$implicit,n=d(2).$implicit,t=d(2).$implicit,s=d(3);r(),l("checked",s.hasPairGrant(t,n,e))("disabled",s.isPairCheckboxDisabled(t,n)),r(),v(" ",e," ")}}function It(c,p){if(c&1&&(a(0,"div",113),x(1,Pt,3,3,"div",114),i()),c&2){let e=d().$implicit,n=d(2).$implicit,t=d(3);r(),l("ngForOf",t.getPairsForSource(n,e))}}function wt(c,p){if(c&1){let e=C();a(0,"div",106)(1,"div",107),h("click",function(){let t=u(e).$implicit,s=d(2).$implicit,m=d(3);return _(m.toggleSourceExpand(s,t))}),a(2,"span",108),o(3),i(),a(4,"mat-checkbox",109),h("change",function(t){let s=u(e).$implicit,m=d(2).$implicit,M=d(3);return _(M.toggleSourceGrant(m,s,t.checked))})("click",function(t){return t.stopPropagation()}),i(),a(5,"span",110),o(6),i(),a(7,"span",111),o(8),i()(),x(9,It,2,1,"div",112),i()}if(c&2){let e=p.$implicit,n=d(2).$implicit,t=d(3);r(3),v(" ",t.isSourceExpanded(n,e)?"expand_more":"chevron_right"," "),r(),l("checked",t.hasSourceGrant(n,e))("indeterminate",t.isSourceIndeterminate(n,e))("disabled",t.hasTypeGrant(n)),r(2),b(e),r(2),de(" ",t.countGrantedPairs(n,e)," / ",t.getPairsForSource(n,e).length," pairs "),r(),l("ngIf",t.isSourceExpanded(n,e))}}function Et(c,p){if(c&1&&(a(0,"div",104),x(1,wt,10,8,"div",105),i()),c&2){let e=d().$implicit,n=d(3);r(),l("ngForOf",n.getSourcesForType(e))}}function Ot(c,p){c&1&&(a(0,"div",99),o(1," No sources discovered for this data type yet. "),i())}function At(c,p){if(c&1){let e=C();a(0,"div",102)(1,"div",70)(2,"span",71),o(3),i(),a(4,"span",72),o(5),i(),x(6,St,2,1,"span",73),g(7,"span",5),a(8,"div",74)(9,"mat-checkbox",75),h("change",function(t){let s=u(e).$implicit,m=d(3);return _(m.toggleTypeGrant(s,t.checked))}),o(10),i()()(),x(11,Et,2,1,"div",103)(12,Ot,2,0,"div",78),i()}if(c&2){let e=p.$implicit,n=d(3);r(3),b(n.dataTypeIcon(e)),r(2),b(n.dataTypeLabels[e]),r(),l("ngIf",!n.hasTypeGrant(e)),r(3),l("checked",n.hasTypeGrant(e)),r(),v(" All ",n.dataTypeLabels[e]," "),r(),l("ngIf",n.getSourcesForType(e).length>0),r(),l("ngIf",n.getSourcesForType(e).length===0)}}function Tt(c,p){if(c&1&&(R(0),a(1,"div",100),o(2," Grant access at the "),a(3,"strong"),o(4,"data type"),i(),o(5,", "),a(6,"strong"),o(7,"source"),i(),o(8,", or individual "),a(9,"strong"),o(10,"pair"),i(),o(11," level. Higher-level grants cascade down automatically. "),i(),x(12,At,13,7,"div",101),G()),c&2){let e=d(2);r(12),l("ngForOf",e.dataTypes)}}function Ut(c,p){if(c&1){let e=C();a(0,"div",41)(1,"div",42)(2,"div",43),o(3),i(),a(4,"div")(5,"div",44),o(6),i(),a(7,"div",45),o(8),i()(),g(9,"span",5),a(10,"button",46),h("click",function(){u(e);let t=d();return _(t.toggleActive(t.selectedUser))}),a(11,"mat-icon"),o(12),i(),o(13),i()(),a(14,"mat-tab-group",47),j("selectedIndexChange",function(t){u(e);let s=d();return q(s.activeTab,t)||(s.activeTab=t),_(t)}),a(15,"mat-tab",48)(16,"div",49)(17,"form",50)(18,"mat-form-field",51)(19,"mat-label"),o(20,"Full Name"),i(),g(21,"input",52),i(),a(22,"mat-form-field",51)(23,"mat-label"),o(24,"Email"),i(),g(25,"input",53),i(),a(26,"mat-form-field",51)(27,"mat-label"),o(28,"Department"),i(),g(29,"input",54),i(),a(30,"div",55)(31,"mat-slide-toggle",56),o(32,"Active Account"),i()(),a(33,"div",57)(34,"button",58),h("click",function(){u(e);let t=d();return _(t.saveProfile())}),o(35),i()()()()(),a(36,"mat-tab",59)(37,"div",49)(38,"div",60),o(39,"Role Assignment"),i(),a(40,"div",61),x(41,bt,9,7,"div",62),i(),a(42,"div",63)(43,"button",8),h("click",function(){u(e);let t=d();return _(t.updateRole())}),o(44,"Update Role"),i()(),g(45,"mat-divider",64),a(46,"div",65)(47,"mat-icon"),o(48,"login"),i(),a(49,"span"),o(50),i()()()(),a(51,"mat-tab",66)(52,"div",67),x(53,ft,4,0,"div",68),a(54,"div",69)(55,"div",70)(56,"span",71),o(57,"analytics"),i(),a(58,"span",72),o(59,"Indicators"),i(),x(60,kt,2,1,"span",73),g(61,"span",5),a(62,"div",74)(63,"mat-checkbox",75),h("change",function(t){u(e);let s=d();return _(s.toggleAllIndicators(t.checked))}),o(64," All Indicators "),i()()(),x(65,vt,4,0,"div",76)(66,Ct,2,1,"div",77)(67,Mt,2,0,"div",78),i(),x(68,Tt,13,1,"ng-container",79),a(69,"div",80)(70,"button",58),h("click",function(){u(e);let t=d();return _(t.saveDataAccess())}),a(71,"mat-icon"),o(72,"save"),i(),o(73),i()()()()()()}if(c&2){let e=d();r(3),b(e.getInitials(e.selectedUser)),r(3),b(e.selectedUser.fullName||e.selectedUser.username),r(2),v("@",e.selectedUser.username),r(4),b(e.selectedUser.isActive?"person_off":"person"),r(),v(" ",e.selectedUser.isActive?"Deactivate":"Activate"," "),r(),B("selectedIndex",e.activeTab),r(3),l("formGroup",e.profileForm),r(17),l("disabled",e.profileForm.invalid||e.saving),r(),v(" ",e.saving?"Saving...":"Save Profile"," "),r(6),l("ngForOf",e.roles),r(9),v("Last login: ",e.formatDate(e.selectedUser.lastLogin)),r(3),l("ngIf",!e.catalogHasData()),r(7),l("ngIf",!e.allIndicatorsGranted),r(3),l("checked",e.allIndicatorsGranted),r(2),l("ngIf",e.indPermLoading),r(),l("ngIf",!e.indPermLoading&&e.allIndicators.length>0),r(),l("ngIf",!e.indPermLoading&&e.allIndicators.length===0),r(),l("ngIf",e.catalogHasData()),r(2),l("disabled",e.accessSaving),r(3),v(" ",e.accessSaving?"Saving...":"Save Data Access"," ")}}function Ft(c,p){c&1&&(a(0,"div",116)(1,"mat-icon"),o(2,"manage_accounts"),i(),a(3,"p"),o(4,"Select a user to view details"),i()())}function Vt(c,p){if(c&1&&(a(0,"mat-option",132),o(1),i()),c&2){let e=p.$implicit;l("value",e),r(),b(e)}}function Dt(c,p){c&1&&(a(0,"div",133)(1,"span",25),o(2,"info"),i(),o(3," This user will authenticate via the corporate directory. No password is stored in the system. "),i())}function Lt(c,p){c&1&&(a(0,"mat-form-field",51)(1,"mat-label"),o(2,"Password"),i(),g(3,"input",134),i())}function zt(c,p){if(c&1){let e=C();a(0,"div",117),h("click",function(){u(e);let t=d();return _(t.closeAddDialog())}),a(1,"div",118),h("click",function(t){return t.stopPropagation()}),a(2,"div",119)(3,"h3"),o(4,"Add New User"),i(),a(5,"button",120),h("click",function(){u(e);let t=d();return _(t.closeAddDialog())}),a(6,"mat-icon"),o(7,"close"),i()()(),a(8,"form",121)(9,"mat-form-field",51)(10,"mat-label"),o(11,"Username"),i(),g(12,"input",122),i(),a(13,"mat-form-field",51)(14,"mat-label"),o(15,"Full Name"),i(),g(16,"input",52),i(),a(17,"mat-form-field",51)(18,"mat-label"),o(19,"Email"),i(),g(20,"input",53),i(),a(21,"mat-form-field",51)(22,"mat-label"),o(23,"Department"),i(),g(24,"input",54),i(),a(25,"mat-form-field",51)(26,"mat-label"),o(27,"Role"),i(),a(28,"mat-select",123),x(29,Vt,2,2,"mat-option",124),i()(),a(30,"div",125)(31,"span",126),o(32,"Authentication"),i(),a(33,"div",127)(34,"button",128),h("click",function(){u(e);let t=d();return _(t.addForm.get("authType").setValue("LOCAL"))}),a(35,"span",25),o(36,"lock"),i(),o(37," Local "),i(),a(38,"button",128),h("click",function(){u(e);let t=d();return _(t.addForm.get("authType").setValue("LDAP"))}),a(39,"span",25),o(40,"corporate_fare"),i(),o(41," LDAP "),i()()(),x(42,Dt,4,0,"div",129)(43,Lt,4,0,"mat-form-field",130),a(44,"div",131)(45,"button",46),h("click",function(){u(e);let t=d();return _(t.closeAddDialog())}),o(46,"Cancel"),i(),a(47,"button",58),h("click",function(){u(e);let t=d();return _(t.addUser())}),o(48),i()()()()()}if(c&2){let e=d();r(8),l("formGroup",e.addForm),r(21),l("ngForOf",e.roles),r(5),y("active",e.addAuthType==="LOCAL"),r(4),y("active",e.addAuthType==="LDAP"),r(4),l("ngIf",e.addAuthType==="LDAP"),r(),l("ngIf",e.addAuthType==="LOCAL"),r(4),l("disabled",e.addForm.invalid||e.addSaving),r(),v(" ",e.addSaving?"Creating...":"Create User"," ")}}function Rt(c,p){c&1&&(R(0),a(1,"mat-form-field",51)(2,"mat-label"),o(3,"LDAP Server URL"),i(),g(4,"input",150),i(),a(5,"mat-form-field",51)(6,"mat-label"),o(7,"Base DN"),i(),g(8,"input",151),i(),a(9,"mat-form-field",51)(10,"mat-label"),o(11,"User DN Pattern"),i(),g(12,"input",152),i(),a(13,"div",133)(14,"span",25),o(15,"info"),i(),o(16," The "),a(17,"strong"),o(18,"{0}"),i(),o(19," placeholder is replaced with the username at login time. Users must exist in the system \u2014 LDAP only verifies the password. "),i(),G())}function Gt(c,p){if(c&1){let e=C();a(0,"div",117),h("click",function(){u(e);let t=d();return _(t.closeAuthSettings())}),a(1,"div",135),h("click",function(t){return t.stopPropagation()}),a(2,"div",119)(3,"mat-icon",136),o(4,"security"),i(),a(5,"h3"),o(6,"Authentication Settings"),i(),a(7,"button",120),h("click",function(){u(e);let t=d();return _(t.closeAuthSettings())}),a(8,"mat-icon"),o(9,"close"),i()()(),a(10,"div",137),o(11," This setting is server-controlled. Switching to LDAP means all users authenticate against your corporate directory. Local passwords are ignored in LDAP mode. "),i(),a(12,"div",138),o(13,"Authentication Mode"),i(),a(14,"form",121)(15,"div",125)(16,"span",126),o(17,"Mode"),i(),a(18,"div",127)(19,"button",128),h("click",function(){u(e);let t=d();return _(t.authSettingsForm.get("mode").setValue("LOCAL"))}),a(20,"span",25),o(21,"lock"),i(),o(22," Local "),i(),a(23,"button",139),h("click",function(){u(e);let t=d();return _(t.authSettingsForm.get("mode").setValue("LDAP"))}),a(24,"span",25),o(25,"corporate_fare"),i(),o(26," LDAP / Active Directory "),i()()(),x(27,Rt,20,0,"ng-container",79),i(),a(28,"div",140),o(29,"Session Security"),i(),a(30,"form",121)(31,"div",141)(32,"div",142)(33,"label",143)(34,"span",25),o(35,"timer_off"),i(),o(36," Idle Timeout "),i(),a(37,"div",144)(38,"mat-form-field",145)(39,"mat-label"),o(40,"Minutes"),i(),g(41,"input",146),i()(),a(42,"span",147),o(43,"Auto-logout after inactivity. Set to 0 to disable."),i()(),a(44,"div",142)(45,"label",143)(46,"span",25),o(47,"schedule"),i(),o(48," Absolute Timeout "),i(),a(49,"div",144)(50,"mat-form-field",145)(51,"mat-label"),o(52,"Minutes"),i(),g(53,"input",148),i()(),a(54,"span",147),o(55,"Hard logout from login time regardless of activity. 0 = disabled. 480 = 8 h."),i()()(),a(56,"div",149)(57,"span",25),o(58,"verified_user"),i(),a(59,"div"),o(60," Sessions are signed with an HMAC derived from the user's credentials. Modifying the session in browser storage will invalidate the signature and force re-authentication \u2014 preventing role elevation attacks. "),i()()(),a(61,"div",131)(62,"button",46),h("click",function(){u(e);let t=d();return _(t.closeAuthSettings())}),o(63,"Cancel"),i(),a(64,"button",58),h("click",function(){u(e);let t=d();return _(t.saveAuthSettings())}),o(65),i()()()()}if(c&2){let e=d();r(14),l("formGroup",e.authSettingsForm),r(5),y("active",e.settingsMode==="LOCAL"),r(4),y("active",e.settingsMode==="LDAP"),r(4),l("ngIf",e.settingsMode==="LDAP"),r(3),l("formGroup",e.securityForm),r(34),l("disabled",e.authSaving||e.authSettingsForm.invalid||e.securityForm.invalid),r(),v(" ",e.authSaving?"Saving...":"Save Settings"," ")}}var Nt={ADMIN:"Full system access, manage users and configuration",APPROVER:"Can approve/reject promotion requests",ANALYST:"Can create indicators and view all data",VIEWER:"Read-only access to dashboards and data"},In=(()=>{class c{userService;authSvc;dataSvc;fb;snackBar;destroy$=new X;users=[];filteredUsers=[];selectedUser=null;stats=null;roles=["ADMIN","ANALYST","VIEWER","APPROVER"];roleDescriptions=Nt;searchQuery="";activeTab=0;loading=!1;saving=!1;profileForm;selectedRole="VIEWER";showAddDialog=!1;addForm;addSaving=!1;showAuthSettings=!1;authConfig={mode:"LOCAL"};authSettingsForm;securityForm;authSaving=!1;dataTypes=it;dataTypeLabels=at;userAccess={username:"",typeGrants:[],sourceGrants:[],pairGrants:[]};expandedSources=new Set;accessSaving=!1;allIndicators=[];indPermissions=new Map;allIndicatorsGranted=!1;indPermLoading=!1;get isAdmin(){return this.authSvc.currentUser?.isAdmin===!0}get isLdapMode(){return this.authConfig.mode==="LDAP"}constructor(e,n,t,s,m){this.userService=e,this.authSvc=n,this.dataSvc=t,this.fb=s,this.snackBar=m,this.profileForm=this.fb.group({fullName:[""],email:["",[f.required,f.email]],department:[""],isActive:[!0]}),this.addForm=this.fb.group({username:["",f.required],email:["",[f.required,f.email]],fullName:["",f.required],department:[""],role:["VIEWER",f.required],authType:["LOCAL",f.required],password:["",f.required]}),this.authSettingsForm=this.fb.group({mode:["LOCAL",f.required],ldapUrl:[""],ldapBaseDn:[""],ldapUserDnPattern:[""]}),this.securityForm=this.fb.group({sessionTimeoutMinutes:[30,[f.required,f.min(0),f.max(1440)]],absoluteTimeoutMinutes:[480,[f.required,f.min(0),f.max(10080)]]}),this.addForm.get("authType").valueChanges.subscribe(M=>{let P=this.addForm.get("password");M==="LDAP"?(P.clearValidators(),P.setValue("")):P.setValidators(f.required),P.updateValueAndValidity()})}ngOnInit(){this.loadUsers(),this.loadStats(),this.loadRoles(),this.authConfig=this.authSvc.getAuthConfig(),this.authSettingsForm.patchValue(this.authConfig),this.securityForm.patchValue(this.authSvc.getSecurityConfig()),this.dataSvc.refreshCatalogFromApi(),this.loadIndicators()}loadIndicators(){}loadIndicatorPermissions(e){this.indPermLoading=!0,this.indPermissions.clear(),this.allIndicators=[],this.allIndicatorsGranted=!1,this.dataSvc.getAllIndicatorPermissions(e).pipe(S(this.destroy$)).subscribe(n=>{this.allIndicators=n.map(t=>({id:t.indicatorId,name:t.indicatorName}));for(let t of n)this.indPermissions.set(t.indicatorId,t);this.syncAllIndicatorsFlag(),this.indPermLoading=!1})}syncAllIndicatorsFlag(){if(this.allIndicators.length===0){this.allIndicatorsGranted=!1;return}this.allIndicatorsGranted=this.allIndicators.every(e=>this.indPermissions.get(e.id)?.canRead===!0)}ngOnDestroy(){this.destroy$.next(),this.destroy$.complete()}loadUsers(){this.loading=!0,this.userService.getUsers().pipe(S(this.destroy$),w(()=>I(null))).subscribe(e=>{e&&e.length>0?this.users=e:this.users=this.authSvc.getStoredUsers().map(n=>({username:n.username,email:n.email,fullName:n.fullName,role:n.role,isAdmin:n.role==="ADMIN",isActive:n.isActive,department:n.department})),this.applyFilter(),this.loading=!1})}loadStats(){this.userService.getStats().pipe(S(this.destroy$),w(()=>I(null))).subscribe(e=>{if(e)this.stats=e;else{let n=this.authSvc.getStoredUsers();this.stats={total:n.length,active:n.filter(t=>t.isActive).length,inactive:n.filter(t=>!t.isActive).length,byRole:n.reduce((t,s)=>(t[s.role]=(t[s.role]||0)+1,t),{})}}})}loadRoles(){this.userService.getRoles().pipe(S(this.destroy$),w(()=>I(this.roles))).subscribe(e=>{this.roles=e.filter(n=>n!=="TRADER")})}applyFilter(){let e=this.searchQuery.toLowerCase().trim();this.filteredUsers=e?this.users.filter(n=>(n.fullName||"").toLowerCase().includes(e)||n.username.toLowerCase().includes(e)||(n.role||"").toLowerCase().includes(e)||(n.email||"").toLowerCase().includes(e)):this.users}selectUser(e){this.selectedUser=e,this.selectedRole=e.role||"VIEWER",this.profileForm.patchValue({fullName:e.fullName||"",email:e.email,department:e.department||"",isActive:e.isActive!==!1}),this.userAccess=this.dataSvc.getAccessForUser(e.username),this.expandedSources.clear(),e.userId&&this.loadIndicatorPermissions(e.userId)}saveProfile(){if(this.profileForm.invalid||!this.selectedUser?.userId)return;this.saving=!0;let e=F(F({},this.selectedUser),this.profileForm.value);this.userService.updateUser(this.selectedUser.userId,e).pipe(S(this.destroy$),w(()=>I(null))).subscribe(n=>{this.saving=!1,n?(this.snackBar.open("Profile saved","Close",{duration:2e3}),this.loadUsers(),this.loadStats()):this.snackBar.open("Save failed","Close",{duration:3e3})})}updateRole(){this.selectedUser?.userId&&this.userService.updateRole(this.selectedUser.userId,this.selectedRole).pipe(S(this.destroy$),w(()=>I(null))).subscribe(e=>{e&&(this.snackBar.open("Role updated","Close",{duration:2e3}),this.selectedUser=e,this.loadUsers(),this.loadStats())})}toggleActive(e){e.userId&&this.userService.toggleActive(e.userId).pipe(S(this.destroy$),w(()=>I(null))).subscribe(n=>{n&&(this.snackBar.open(`User ${n.isActive?"activated":"deactivated"}`,"Close",{duration:2e3}),this.selectedUser?.userId===n.userId&&(this.selectedUser=n,this.profileForm.patchValue({isActive:n.isActive})),this.loadUsers(),this.loadStats())})}openAddDialog(){this.addForm.reset({role:"VIEWER",authType:"LOCAL"}),this.showAddDialog=!0}closeAddDialog(){this.showAddDialog=!1}get addAuthType(){return this.addForm.get("authType")?.value||"LOCAL"}addUser(){if(this.addForm.invalid)return;this.addSaving=!0;let e=this.addForm.value,n={username:e.username,password:e.authType==="LDAP"?"":e.password,fullName:e.fullName,role:e.role,email:e.email,department:e.department,isActive:!0,authType:e.authType},t=this.authSvc.getStoredUsers();if(t.find(m=>m.username.toLowerCase()===e.username.toLowerCase())){this.snackBar.open("Username already exists","Close",{duration:3e3}),this.addSaving=!1;return}t.push(n),this.authSvc.saveUsers(t),this.addSaving=!1,this.showAddDialog=!1,this.snackBar.open("User created","Close",{duration:2e3}),this.loadUsers(),this.loadStats();let s={username:e.username,email:e.email,fullName:e.fullName,department:e.department,role:e.role,passwordHash:e.authType==="LDAP"?"LDAP_AUTH":"HASHED_"+e.password,isAdmin:e.role==="ADMIN",isActive:!0};this.userService.createUser(s).pipe(S(this.destroy$),w(()=>I(null))).subscribe()}openAuthSettings(){this.authConfig=this.authSvc.getAuthConfig(),this.authSettingsForm.patchValue(this.authConfig),this.securityForm.patchValue(this.authSvc.getSecurityConfig()),this.showAuthSettings=!0}closeAuthSettings(){this.showAuthSettings=!1}get settingsMode(){return this.authSettingsForm.get("mode")?.value||"LOCAL"}saveAuthSettings(){if(this.authSettingsForm.invalid||this.securityForm.invalid)return;this.authSaving=!0;let e=this.authSettingsForm.value,n={mode:e.mode,ldapUrl:e.ldapUrl||void 0,ldapBaseDn:e.ldapBaseDn||void 0,ldapUserDnPattern:e.ldapUserDnPattern||void 0};this.authSvc.saveAuthConfig(n),this.authConfig=n;let t=this.securityForm.value,s={sessionTimeoutMinutes:Number(t.sessionTimeoutMinutes),absoluteTimeoutMinutes:Number(t.absoluteTimeoutMinutes)};this.authSvc.saveSecurityConfig(s),this.authSaving=!1,this.showAuthSettings=!1,this.snackBar.open("Security settings saved","Close",{duration:3e3})}getInitials(e){return(e.fullName||e.username).split(" ").map(t=>t[0]).join("").toUpperCase().substring(0,2)}roleBadgeClass(e){switch(e){case"ADMIN":return"role-admin";case"APPROVER":return"role-approver";case"ANALYST":return"role-analyst";default:return"role-viewer"}}statsCount(e){return this.stats?.byRole?.[e]||0}formatDate(e){return e?new Date(e).toLocaleString():"Never"}getSourcesForType(e){return this.dataSvc.getSourcesForType(e)}getPairsForSource(e,n){return this.dataSvc.getPairsForSource(e,n)}toggleSourceExpand(e,n){let t=`${e}|${n}`;this.expandedSources.has(t)?this.expandedSources.delete(t):this.expandedSources.add(t)}isSourceExpanded(e,n){return this.expandedSources.has(`${e}|${n}`)}hasTypeGrant(e){return this.userAccess.typeGrants.includes(e)}toggleTypeGrant(e,n){n?(this.userAccess.typeGrants.includes(e)||this.userAccess.typeGrants.push(e),this.userAccess.sourceGrants=this.userAccess.sourceGrants.filter(t=>t.dataType!==e),this.userAccess.pairGrants=this.userAccess.pairGrants.filter(t=>t.dataType!==e)):this.userAccess.typeGrants=this.userAccess.typeGrants.filter(t=>t!==e)}hasSourceGrant(e,n){return this.userAccess.typeGrants.includes(e)||this.userAccess.sourceGrants.some(t=>t.dataType===e&&t.source===n)}isSourceIndeterminate(e,n){if(this.hasTypeGrant(e)||this.hasSourceGrant(e,n))return!1;let t=this.getPairsForSource(e,n),s=t.filter(m=>this.hasPairGrant(e,n,m));return s.length>0&&s.length<t.length}toggleSourceGrant(e,n,t){this.hasTypeGrant(e)||(t?(this.userAccess.sourceGrants.some(s=>s.dataType===e&&s.source===n)||this.userAccess.sourceGrants.push({dataType:e,source:n}),this.userAccess.pairGrants=this.userAccess.pairGrants.filter(s=>!(s.dataType===e&&s.source===n))):(this.userAccess.sourceGrants=this.userAccess.sourceGrants.filter(s=>!(s.dataType===e&&s.source===n)),this.userAccess.pairGrants=this.userAccess.pairGrants.filter(s=>!(s.dataType===e&&s.source===n))))}hasPairGrant(e,n,t){return this.userAccess.typeGrants.includes(e)||this.userAccess.sourceGrants.some(s=>s.dataType===e&&s.source===n)||this.userAccess.pairGrants.some(s=>s.dataType===e&&s.source===n&&s.pair===t)}isPairCheckboxDisabled(e,n){return this.hasTypeGrant(e)||this.userAccess.sourceGrants.some(t=>t.dataType===e&&t.source===n)}togglePairGrant(e,n,t,s){this.isPairCheckboxDisabled(e,n)||(s?this.userAccess.pairGrants.some(m=>m.dataType===e&&m.source===n&&m.pair===t)||this.userAccess.pairGrants.push({dataType:e,source:n,pair:t}):this.userAccess.pairGrants=this.userAccess.pairGrants.filter(m=>!(m.dataType===e&&m.source===n&&m.pair===t)))}countGrantedPairs(e,n){let t=this.getPairsForSource(e,n);return this.hasTypeGrant(e)||this.userAccess.sourceGrants.some(s=>s.dataType===e&&s.source===n)?t.length:t.filter(s=>this.hasPairGrant(e,n,s)).length}saveDataAccess(){if(!this.selectedUser)return;this.accessSaving=!0,this.userAccess.username=this.selectedUser.username,this.dataSvc.saveAccessForUser(this.userAccess);let e=this.selectedUser.userId,n=this.authSvc.currentUser?.username??"",s=this.users.find(m=>m.username.toLowerCase()===n.toLowerCase())?.userId??e;if(e){let m=this.allIndicators.map(T=>{let U=this.indPermissions.get(T.id);return U?.canRead||U?.canExecute?this.dataSvc.grantIndicatorPermission(T.id,e,U.canRead,U.canExecute,s):this.dataSvc.revokeIndicatorPermission(T.id,e)}),M=0,P=m.length;if(P===0){this.accessSaving=!1,this.snackBar.open("Data access saved","Close",{duration:2e3});return}for(let T of m)T.pipe(S(this.destroy$)).subscribe(()=>{++M===P&&(this.accessSaving=!1,this.snackBar.open("Data access saved","Close",{duration:2e3}))})}else this.accessSaving=!1,this.snackBar.open("Data access saved","Close",{duration:2e3})}hasIndRead(e){return this.indPermissions.get(e.id)?.canRead===!0}hasIndExecute(e){return this.indPermissions.get(e.id)?.canExecute===!0}toggleIndRead(e,n){let t=this.indPermissions.get(e.id);n?this.indPermissions.set(e.id,{indicatorId:e.id,indicatorName:e.name,canRead:!0,canExecute:t?.canExecute??!1}):this.indPermissions.set(e.id,{indicatorId:e.id,indicatorName:e.name,canRead:!1,canExecute:!1}),this.syncAllIndicatorsFlag()}toggleIndExecute(e,n){let t=this.indPermissions.get(e.id)??{indicatorId:e.id,indicatorName:e.name,canRead:!1,canExecute:!1};this.indPermissions.set(e.id,Q(F({},t),{canExecute:n,canRead:n?!0:t.canRead})),this.syncAllIndicatorsFlag()}toggleAllIndicators(e){this.allIndicatorsGranted=e;for(let n of this.allIndicators)this.indPermissions.set(n.id,{indicatorId:n.id,indicatorName:n.name,canRead:e,canExecute:e?this.indPermissions.get(n.id)?.canExecute??!1:!1})}dataTypeIcon(e){return e==="market"?"candlestick_chart":e==="post_trade"?"receipt_long":"pending_actions"}catalogHasData(){return this.dataSvc.getCatalog().length>0}static \u0275fac=function(n){return new(n||c)(A(qe),A(be),A(ot),A(Ae),A(tt))};static \u0275cmp=V({type:c,selectors:[["app-user-management"]],decls:28,vars:9,consts:[["noSelection",""],[1,"um-page"],[1,"um-topbar"],[1,"um-icon"],[1,"um-title"],[1,"spacer"],["class","stats-chips",4,"ngIf"],["class","auth-mode-chip","matTooltip","Click to configure authentication",3,"ldap-chip","click",4,"ngIf"],["mat-raised-button","","color","primary",3,"click"],[1,"um-body"],[1,"um-list"],["appearance","outline",1,"list-search"],["matInput","","placeholder","Name, username, role...",3,"ngModelChange","ngModel"],["matPrefix",""],["class","list-loading",4,"ngIf"],["class","user-list-items",4,"ngIf"],["class","um-detail",4,"ngIf","ngIfElse"],["class","um-dialog-overlay",3,"click",4,"ngIf"],[1,"stats-chips"],[1,"stat-chip"],[1,"chip-val"],[1,"chip-lbl"],[1,"stat-chip","chip-active"],[1,"stat-chip","chip-inactive"],["matTooltip","Click to configure authentication",1,"auth-mode-chip",3,"click"],[1,"material-icons"],[1,"material-icons","settings-cog"],[1,"list-loading"],["diameter","28"],[1,"user-list-items"],["class","list-empty",4,"ngIf"],["class","user-row",3,"selected","click",4,"ngFor","ngForOf"],[1,"list-empty"],[1,"user-row",3,"click"],[1,"user-avatar"],[1,"user-info"],[1,"user-name"],[1,"user-username"],[1,"user-right"],[1,"role-badge",3,"ngClass"],[1,"active-dot",3,"matTooltip"],[1,"um-detail"],[1,"detail-header"],[1,"detail-avatar"],[1,"detail-name"],[1,"detail-username"],["mat-stroked-button","",3,"click"],[3,"selectedIndexChange","selectedIndex"],["label","Profile"],[1,"tab-content"],[1,"profile-form",3,"formGroup"],["appearance","outline",1,"full-width"],["matInput","","formControlName","fullName"],["matInput","","formControlName","email","type","email"],["matInput","","formControlName","department"],[1,"toggle-row"],["formControlName","isActive"],[1,"form-actions"],["mat-raised-button","","color","primary",3,"click","disabled"],["label","Permissions"],[1,"perm-section-title"],[1,"role-selector"],["class","role-option",3,"role-selected","click",4,"ngFor","ngForOf"],[1,"perm-actions"],[1,"perm-divider"],[1,"last-login-row"],["label","Data Access"],[1,"tab-content","da-tab"],["class","da-empty-notice",4,"ngIf"],[1,"da-type-card","da-ind-card"],[1,"da-type-header"],[1,"material-icons","da-type-icon"],[1,"da-type-label"],["class","da-type-count",4,"ngIf"],[1,"da-type-grant"],["color","primary",3,"change","checked"],["class","da-ind-loading",4,"ngIf"],["class","da-ind-list",4,"ngIf"],["class","da-no-sources",4,"ngIf"],[4,"ngIf"],[1,"da-actions"],[1,"role-option",3,"click"],[1,"role-radio"],[1,"radio-dot"],[1,"role-info"],[1,"role-name"],[1,"role-badge-sm",3,"ngClass"],[1,"role-desc"],[1,"da-empty-notice"],[1,"da-type-count"],[1,"da-ind-loading"],["diameter","20"],[1,"da-ind-list"],["class","da-ind-row",4,"ngFor","ngForOf"],[1,"da-ind-row"],[1,"da-ind-name"],[1,"da-ind-checks"],["color","primary",3,"change","checked","disabled"],["color","accent",3,"change","checked","disabled"],[1,"da-no-sources"],[1,"da-intro"],["class","da-type-card",4,"ngFor","ngForOf"],[1,"da-type-card"],["class","da-sources",4,"ngIf"],[1,"da-sources"],["class","da-source-row",4,"ngFor","ngForOf"],[1,"da-source-row"],[1,"da-source-header",3,"click"],[1,"material-icons","da-expand-icon"],["color","primary",3,"change","click","checked","indeterminate","disabled"],[1,"da-source-name"],[1,"da-pair-count"],["class","da-pairs-grid",4,"ngIf"],[1,"da-pairs-grid"],["class","da-pair-item",4,"ngFor","ngForOf"],[1,"da-pair-item"],[1,"um-no-selection"],[1,"um-dialog-overlay",3,"click"],[1,"um-dialog",3,"click"],[1,"dialog-header"],["mat-icon-button","",3,"click"],[1,"add-form",3,"formGroup"],["matInput","","formControlName","username"],["formControlName","role"],[3,"value",4,"ngFor","ngForOf"],[1,"auth-type-row"],[1,"auth-type-label"],[1,"auth-type-toggle"],["type","button",1,"auth-type-btn",3,"click"],["class","ldap-info-box",4,"ngIf"],["appearance","outline","class","full-width",4,"ngIf"],[1,"dialog-actions"],[3,"value"],[1,"ldap-info-box"],["matInput","","formControlName","password","type","password"],[1,"um-dialog","auth-settings-dialog",3,"click"],[2,"color","#3b82f6"],[1,"auth-settings-note"],[1,"settings-section-title"],["type","button",1,"auth-type-btn","ldap-btn",3,"click"],[1,"settings-section-title","settings-section-divider"],[1,"session-timeout-grid"],[1,"session-field"],[1,"session-label"],[1,"session-input-row"],["appearance","outline",1,"timeout-field"],["matInput","","type","number","formControlName","sessionTimeoutMinutes","min","0","max","1440"],[1,"session-hint"],["matInput","","type","number","formControlName","absoluteTimeoutMinutes","min","0","max","10080"],[1,"security-info-box"],["matInput","","formControlName","ldapUrl","placeholder","ldap://corp.example.com:389"],["matInput","","formControlName","ldapBaseDn","placeholder","dc=corp,dc=example,dc=com"],["matInput","","formControlName","ldapUserDnPattern","placeholder","uid={0},ou=people"]],template:function(n,t){if(n&1){let s=C();a(0,"div",1)(1,"div",2)(2,"mat-icon",3),o(3,"manage_accounts"),i(),a(4,"h2",4),o(5,"User Management"),i(),g(6,"span",5),x(7,pt,16,3,"div",6)(8,ht,6,4,"div",7),a(9,"button",8),h("click",function(){return t.openAddDialog()}),a(10,"mat-icon"),o(11,"person_add"),i(),o(12," Add User "),i()(),a(13,"div",9)(14,"div",10)(15,"mat-form-field",11)(16,"mat-label"),o(17,"Search users"),i(),a(18,"input",12),j("ngModelChange",function(M){return u(s),q(t.searchQuery,M)||(t.searchQuery=M),_(M)}),h("ngModelChange",function(){return t.applyFilter()}),i(),a(19,"mat-icon",13),o(20,"search"),i()(),x(21,ut,2,0,"div",14)(22,xt,3,2,"div",15),i(),x(23,Ut,74,20,"div",16)(24,Ft,5,0,"ng-template",null,0,me),i(),x(26,zt,49,10,"div",17)(27,Gt,66,9,"div",17),i()}if(n&2){let s=D(25);r(7),l("ngIf",t.stats),r(),l("ngIf",t.isAdmin),r(10),B("ngModel",t.searchQuery),r(3),l("ngIf",t.loading),r(),l("ngIf",!t.loading),r(),l("ngIf",t.selectedUser)("ngIfElse",s),r(3),l("ngIf",t.showAddDialog),r(),l("ngIf",t.showAuthSettings)}},dependencies:[Le,xe,ge,_e,Be,$e,We,je,Ye,Te,Se,ke,Pe,ye,Ce,Oe,Ee,Me,He,Ve,Re,Xe,Qe,Ue,we,Ie,et,nt,Ke,Ze,ct],styles:[".um-page[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100vh;background:#f5f5f5;overflow:hidden}.um-topbar[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;background:#fff;border-bottom:1px solid #e0e0e0;padding:10px 20px;flex-shrink:0}.um-topbar[_ngcontent-%COMP%]   .um-icon[_ngcontent-%COMP%]{color:#1976d2;font-size:26px}.um-topbar[_ngcontent-%COMP%]   .um-title[_ngcontent-%COMP%]{margin:0;font-size:20px;font-weight:600;color:#333}.um-topbar[_ngcontent-%COMP%]   .spacer[_ngcontent-%COMP%]{flex:1}.stats-chips[_ngcontent-%COMP%]{display:flex;gap:8px}.stat-chip[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;background:#f5f5f5;border:1px solid #e0e0e0;border-radius:8px;padding:4px 14px;min-width:60px}.stat-chip[_ngcontent-%COMP%]   .chip-val[_ngcontent-%COMP%]{font-size:18px;font-weight:700;color:#333}.stat-chip[_ngcontent-%COMP%]   .chip-lbl[_ngcontent-%COMP%]{font-size:10px;color:#888}.stat-chip.chip-active[_ngcontent-%COMP%]   .chip-val[_ngcontent-%COMP%]{color:#388e3c}.stat-chip.chip-inactive[_ngcontent-%COMP%]   .chip-val[_ngcontent-%COMP%]{color:#f57c00}.um-body[_ngcontent-%COMP%]{display:grid;grid-template-columns:300px 1fr;flex:1;overflow:hidden}.um-list[_ngcontent-%COMP%]{background:#fff;border-right:1px solid #e0e0e0;display:flex;flex-direction:column;overflow:hidden;padding:12px;gap:8px}.list-search[_ngcontent-%COMP%]{width:100%}.list-loading[_ngcontent-%COMP%], .list-empty[_ngcontent-%COMP%]{padding:24px;text-align:center;color:#aaa;font-size:13px}.user-list-items[_ngcontent-%COMP%]{overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:4px}.user-row[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;transition:background .15s}.user-row[_ngcontent-%COMP%]:hover{background:#f5f5f5}.user-row.selected[_ngcontent-%COMP%]{background:#e3f2fd}.user-avatar[_ngcontent-%COMP%]{width:38px;height:38px;border-radius:50%;background:#1976d2;color:#fff;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;flex-shrink:0}.user-avatar.inactive-avatar[_ngcontent-%COMP%]{background:#bdbdbd}.user-info[_ngcontent-%COMP%]{flex:1;min-width:0}.user-info[_ngcontent-%COMP%]   .user-name[_ngcontent-%COMP%]{font-size:13px;font-weight:600;color:#333;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.user-info[_ngcontent-%COMP%]   .user-username[_ngcontent-%COMP%]{font-size:11px;color:#888}.user-right[_ngcontent-%COMP%]{display:flex;align-items:center;gap:6px;flex-shrink:0}.active-dot[_ngcontent-%COMP%]{width:8px;height:8px;border-radius:50%}.active-dot.dot-active[_ngcontent-%COMP%]{background:#4caf50}.active-dot.dot-inactive[_ngcontent-%COMP%]{background:#bdbdbd}.role-badge[_ngcontent-%COMP%]{padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;text-transform:uppercase;white-space:nowrap}.role-badge.role-admin[_ngcontent-%COMP%]{background:#fce4ec;color:#c62828}.role-badge.role-approver[_ngcontent-%COMP%]{background:#f3e5f5;color:#6a1b9a}.role-badge.role-analyst[_ngcontent-%COMP%]{background:#e3f2fd;color:#1565c0}.role-badge.role-trader[_ngcontent-%COMP%]{background:#e8f5e9;color:#2e7d32}.role-badge.role-viewer[_ngcontent-%COMP%]{background:#f5f5f5;color:#616161}.um-detail[_ngcontent-%COMP%]{overflow-y:auto;background:#f5f5f5;padding:16px;display:flex;flex-direction:column;gap:12px}.detail-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:14px;background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:16px}.detail-header[_ngcontent-%COMP%]   .spacer[_ngcontent-%COMP%]{flex:1}.detail-avatar[_ngcontent-%COMP%]{width:52px;height:52px;border-radius:50%;background:#1976d2;color:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;flex-shrink:0}.detail-name[_ngcontent-%COMP%]{font-size:16px;font-weight:700;color:#333}.detail-username[_ngcontent-%COMP%]{font-size:12px;color:#888}.tab-content[_ngcontent-%COMP%]{padding:16px}.profile-form[_ngcontent-%COMP%]{background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:16px;display:flex;flex-direction:column;gap:4px}.full-width[_ngcontent-%COMP%]{width:100%}.toggle-row[_ngcontent-%COMP%]{margin:8px 0}.form-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;margin-top:8px}.perm-section-title[_ngcontent-%COMP%]{font-size:13px;font-weight:700;color:#555;margin-bottom:12px}.role-selector[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px;background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:12px;margin-bottom:16px}.role-option[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px;padding:10px;border-radius:8px;cursor:pointer;transition:background .15s}.role-option[_ngcontent-%COMP%]:hover{background:#f5f5f5}.role-option.role-selected[_ngcontent-%COMP%]{background:#e3f2fd}.role-radio[_ngcontent-%COMP%]{width:18px;height:18px;border-radius:50%;border:2px solid #bdbdbd;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:2px}.role-radio[_ngcontent-%COMP%]   .radio-dot[_ngcontent-%COMP%]{width:8px;height:8px;border-radius:50%;background:transparent}.role-radio[_ngcontent-%COMP%]   .radio-dot.radio-active[_ngcontent-%COMP%]{background:#1976d2}.role-info[_ngcontent-%COMP%]{flex:1}.role-info[_ngcontent-%COMP%]   .role-name[_ngcontent-%COMP%]{margin-bottom:3px}.role-info[_ngcontent-%COMP%]   .role-desc[_ngcontent-%COMP%]{font-size:12px;color:#666}.role-badge-sm[_ngcontent-%COMP%]{padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;text-transform:uppercase}.role-badge-sm.role-admin[_ngcontent-%COMP%]{background:#fce4ec;color:#c62828}.role-badge-sm.role-approver[_ngcontent-%COMP%]{background:#f3e5f5;color:#6a1b9a}.role-badge-sm.role-analyst[_ngcontent-%COMP%]{background:#e3f2fd;color:#1565c0}.role-badge-sm.role-trader[_ngcontent-%COMP%]{background:#e8f5e9;color:#2e7d32}.role-badge-sm.role-viewer[_ngcontent-%COMP%]{background:#f5f5f5;color:#616161}.perm-actions[_ngcontent-%COMP%]{margin-bottom:16px}.perm-divider[_ngcontent-%COMP%]{margin:16px 0}.last-login-row[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;font-size:13px;color:#666}.last-login-row[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;color:#1976d2}.um-no-selection[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:#ccc}.um-no-selection[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:64px;width:64px;height:64px;margin-bottom:12px}.um-no-selection[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:14px}.um-dialog-overlay[_ngcontent-%COMP%]{position:fixed;inset:0;background:#0006;display:flex;align-items:center;justify-content:center;z-index:1000}.um-dialog[_ngcontent-%COMP%]{background:#fff;border-radius:12px;width:480px;max-width:95vw;padding:24px;box-shadow:0 8px 32px #0003}.dialog-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}.dialog-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0;font-size:17px;font-weight:700;color:#333}.add-form[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px}.dialog-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;gap:8px;margin-top:12px}@media(max-width:768px){.um-body[_ngcontent-%COMP%]{grid-template-columns:1fr;overflow-y:auto}.um-list[_ngcontent-%COMP%]{max-height:50vh}}.auth-mode-chip[_ngcontent-%COMP%]{display:flex;align-items:center;gap:5px;font-size:11px;font-weight:600;letter-spacing:.03em;padding:5px 11px;border-radius:20px;border:1px solid #e0e0e0;background:#f5f5f5;color:#666;cursor:pointer;transition:background .16s,border-color .16s;-webkit-user-select:none;user-select:none}.auth-mode-chip[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:15px!important}.auth-mode-chip[_ngcontent-%COMP%]   .settings-cog[_ngcontent-%COMP%]{font-size:13px!important;opacity:.5}.auth-mode-chip[_ngcontent-%COMP%]:hover{background:#eee;border-color:#bbb}.auth-mode-chip.ldap-chip[_ngcontent-%COMP%]{background:#3b82f614;border-color:#3b82f640;color:#2563eb}.auth-mode-chip.ldap-chip[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#3b82f6}.auth-mode-chip.ldap-chip[_ngcontent-%COMP%]:hover{background:#3b82f624}.auth-type-row[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;margin-bottom:16px}.auth-type-label[_ngcontent-%COMP%]{font-size:12px;font-weight:600;color:#555;white-space:nowrap}.auth-type-toggle[_ngcontent-%COMP%]{display:flex;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden}.auth-type-btn[_ngcontent-%COMP%]{display:flex;align-items:center;gap:5px;padding:7px 14px;background:#fff;border:none;border-right:1px solid #e0e0e0;font-size:12px;font-weight:500;font-family:Plus Jakarta Sans,sans-serif;color:#666;cursor:pointer;transition:background .14s,color .14s}.auth-type-btn[_ngcontent-%COMP%]:last-child{border-right:none}.auth-type-btn[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:15px!important}.auth-type-btn.active[_ngcontent-%COMP%]{background:#1976d2;color:#fff}.auth-type-btn.active[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{color:#fff}.auth-type-btn.ldap-btn.active[_ngcontent-%COMP%]{background:#2563eb}.ldap-info-box[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:8px;background:#3b82f612;border:1px solid rgba(59,130,246,.2);border-radius:8px;padding:10px 14px;font-size:12px;color:#1d4ed8;margin-bottom:16px;line-height:1.5}.ldap-info-box[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:16px!important;flex-shrink:0;margin-top:1px}.ldap-info-box[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-weight:700}.auth-settings-dialog[_ngcontent-%COMP%]{max-width:560px!important}.auth-settings-note[_ngcontent-%COMP%]{font-size:12px;color:#666;background:#f9f9f9;border:1px solid #e8e8e8;border-radius:8px;padding:10px 14px;margin-bottom:20px;line-height:1.6}.settings-section-title[_ngcontent-%COMP%]{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#666;padding:0 20px 8px}.settings-section-divider[_ngcontent-%COMP%]{padding-top:16px;border-top:1px solid #f0f0f0;margin-top:4px}.session-timeout-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:0 0 8px}.session-field[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px}.session-label[_ngcontent-%COMP%]{display:flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:#444;margin-bottom:4px}.session-label[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:15px!important;color:#1976d2}.session-input-row[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px}.timeout-field[_ngcontent-%COMP%]{width:100%}.session-hint[_ngcontent-%COMP%]{font-size:10.5px;color:#888;line-height:1.4}.security-info-box[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:10px;background:#22c55e0f;border:1px solid rgba(34,197,94,.25);border-radius:8px;padding:12px 14px;font-size:12px;color:#166534;line-height:1.6;margin-bottom:8px}.security-info-box[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:18px!important;flex-shrink:0;color:#16a34a;margin-top:1px}.da-tab[_ngcontent-%COMP%]{padding:16px 0!important}.da-empty-notice[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;background:#f8faff;border:1px solid #dbeafe;border-radius:8px;padding:14px 16px;font-size:13px;color:#2563eb;margin-bottom:16px}.da-empty-notice[_ngcontent-%COMP%]   .material-icons[_ngcontent-%COMP%]{font-size:17px!important;flex-shrink:0}.da-intro[_ngcontent-%COMP%]{font-size:12.5px;color:#555;margin-bottom:16px;line-height:1.6;padding:0 2px}.da-type-card[_ngcontent-%COMP%]{border:1px solid #e8e8e8;border-radius:10px;margin-bottom:12px;overflow:hidden;background:#fff}.da-type-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;padding:12px 16px;background:#f7f9ff;border-bottom:1px solid #eee}.da-type-header[_ngcontent-%COMP%]   .spacer[_ngcontent-%COMP%]{flex:1}.da-type-icon[_ngcontent-%COMP%]{font-size:18px!important;color:#1976d2;flex-shrink:0}.da-type-label[_ngcontent-%COMP%]{font-size:13px;font-weight:700;color:#222;letter-spacing:.01em}.da-type-count[_ngcontent-%COMP%]{font-size:11px;color:#888;background:#f0f0f0;border-radius:10px;padding:2px 8px}.da-type-grant[_ngcontent-%COMP%]{font-size:13px}.da-sources[_ngcontent-%COMP%]{padding:0 0 4px}.da-source-row[_ngcontent-%COMP%]{border-bottom:1px solid #f4f4f4}.da-source-row[_ngcontent-%COMP%]:last-child{border-bottom:none}.da-source-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;padding:9px 16px;cursor:pointer;transition:background .12s}.da-source-header[_ngcontent-%COMP%]:hover{background:#fafafa}.da-expand-icon[_ngcontent-%COMP%]{font-size:18px!important;color:#bbb;flex-shrink:0;transition:transform .18s}.da-source-name[_ngcontent-%COMP%]{font-size:12.5px;font-weight:600;color:#333;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.da-pair-count[_ngcontent-%COMP%]{font-size:11px;color:#888;white-space:nowrap;margin-left:auto;padding-right:4px}.da-pairs-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:2px 0;padding:4px 16px 10px 48px;background:#fafafa}.da-pair-item[_ngcontent-%COMP%]{font-size:12px}.da-no-sources[_ngcontent-%COMP%]{font-size:12px;color:#aaa;padding:10px 16px;font-style:italic}.da-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;padding:16px 2px 4px}.da-ind-card[_ngcontent-%COMP%]{border-color:#e3eafd}.da-ind-card[_ngcontent-%COMP%]   .da-type-header[_ngcontent-%COMP%]{background:#f0f4ff}.da-ind-card[_ngcontent-%COMP%]   .da-type-icon[_ngcontent-%COMP%]{color:#5c6bc0}.da-ind-loading[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;padding:12px 16px;font-size:12px;color:#888}.da-ind-list[_ngcontent-%COMP%]{padding:0 0 4px}.da-ind-row[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;padding:8px 16px;border-bottom:1px solid #f4f4f4;gap:12px}.da-ind-row[_ngcontent-%COMP%]:last-child{border-bottom:none}.da-ind-row[_ngcontent-%COMP%]:hover{background:#fafbff}.da-ind-name[_ngcontent-%COMP%]{font-size:12.5px;font-weight:500;color:#333;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.da-ind-checks[_ngcontent-%COMP%]{display:flex;align-items:center;gap:16px;flex-shrink:0}"]})}return c})();export{In as UserManagementComponent};
